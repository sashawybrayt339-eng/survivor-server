Optional high-detail models. If these files exist, they replace the built-in procedural ones:
  tree.glb     - a realistic tree (keep it about 6 m tall, origin at the base)
  pumpkin.glb  - a realistic pumpkin (about 1 m across, origin at the base)
