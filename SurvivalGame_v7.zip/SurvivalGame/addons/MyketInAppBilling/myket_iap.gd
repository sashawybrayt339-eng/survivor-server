class_name MyketIAP
extends RefCounted

const PLUGIN_NAME := "MyketInAppBilling"

var _plugin: Object


func _init() -> void:
	if Engine.has_singleton(PLUGIN_NAME):
		_plugin = Engine.get_singleton(PLUGIN_NAME)


func is_available() -> bool:
	return _plugin != null


func get_plugin() -> Object:
	return _plugin
