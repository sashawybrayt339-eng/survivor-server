extends Node3D

# First-person stone axe. The mesh comes from a scan of a real stone axe
# (see axe_mesh_data.gd). It is attached to the player's camera.

const MeshData = preload("res://scripts/axe_mesh_data.gd")
const BASE_ROTATION := Vector3(-34.0, 0.0, 0.0)
const HOLD_POSITION := Vector3(0.3, -0.46, -0.52)
const MODEL_SCALE := 1.0

static var _mesh_cache: ArrayMesh = null
static var _mat_cache: StandardMaterial3D = null

var _model: MeshInstance3D
var _tween: Tween


static func build_mesh() -> ArrayMesh:
	if _mesh_cache != null:
		return _mesh_cache
	var positions := PackedVector3Array()
	var normals := PackedVector3Array()
	var indices := PackedInt32Array()
	var raw_p: Array = MeshData.POSITIONS
	var raw_n: Array = MeshData.NORMALS
	var raw_i: Array = MeshData.INDICES
	for i in range(0, raw_p.size(), 3):
		positions.append(Vector3(raw_p[i], raw_p[i + 1], raw_p[i + 2]))
	for i in range(0, raw_n.size(), 3):
		normals.append(Vector3(raw_n[i], raw_n[i + 1], raw_n[i + 2]))
	for v in raw_i:
		indices.append(int(v))
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = positions
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_INDEX] = indices
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	_mesh_cache = mesh
	return mesh


static func axe_material() -> StandardMaterial3D:
	if _mat_cache == null:
		_mat_cache = StandardMaterial3D.new()
		_mat_cache.albedo_color = Color(0.5, 0.46, 0.4)
		_mat_cache.roughness = 0.93
		_mat_cache.metallic_specular = 0.3
		_mat_cache.cull_mode = BaseMaterial3D.CULL_DISABLED
	return _mat_cache


func _ready() -> void:
	position = HOLD_POSITION
	rotation_degrees = BASE_ROTATION
	_model = MeshInstance3D.new()
	_model.mesh = build_mesh()
	_model.material_override = axe_material()
	# Grip sits around the lower part of the handle.
	_model.position = Vector3(0.0, -0.18, 0.0)
	_model.scale = Vector3.ONE * MODEL_SCALE
	add_child(_model)
	visible = false


func set_equipped(on: bool) -> void:
	visible = on


# Wind up, chop down, return to rest.
func swing() -> void:
	if _tween != null and _tween.is_valid():
		_tween.kill()
	_tween = create_tween()
	_tween.tween_property(self, "rotation_degrees", BASE_ROTATION + Vector3(55.0, 0.0, 0.0), 0.10)
	_tween.tween_property(self, "rotation_degrees", BASE_ROTATION + Vector3(-85.0, 0.0, 0.0), 0.10)
	_tween.tween_property(self, "rotation_degrees", BASE_ROTATION, 0.30)
