extends Control

# Round minimap of the whole world. Tap it to put a waypoint on the map.
# With full = true it fills the screen (the "full map" view).
signal target_set(world_xz: Vector2)

var full := false
var _map: Texture2D = null
var _world_size := 1000.0
var _player_xz := Vector2.ZERO
var _yaw := 0.0
var _has_target := false
var _target := Vector2.ZERO


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP


func setup(tex: Texture2D, world_size: float) -> void:
	_map = tex
	_world_size = world_size
	queue_redraw()


func set_state(player_xz: Vector2, yaw: float, has_target: bool, target: Vector2) -> void:
	_player_xz = player_xz
	_yaw = yaw
	_has_target = has_target
	_target = target
	queue_redraw()


func _side() -> float:
	return minf(size.x, size.y)


func _center() -> Vector2:
	return size * 0.5


# World (x, z) -> pixel. The map is a square of side _side(), centred on the screen.
func _to_px(xz: Vector2) -> Vector2:
	return _center() + xz / _world_size * _side()


func _draw() -> void:
	var s := _side()
	var c := _center()
	var r := s * 0.5
	if full:
		draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, 0.8))
	var rect := Rect2(c - Vector2(r, r), Vector2(s, s))
	if _map != null:
		draw_texture_rect(_map, rect, false)
	else:
		draw_circle(c, r, Color(0.14, 0.32, 0.14))
	draw_arc(c, r - 2.0, 0.0, TAU, 96, Color(0.7, 1.0, 0.45), 4.0)

	if _has_target:
		var p := _to_px(_target)
		var off := p - c
		if off.length() > r - 12.0:
			p = c + off.normalized() * (r - 12.0)
		var m := 9.0 if not full else 14.0
		draw_colored_polygon(PackedVector2Array([
			p + Vector2(0, -m), p + Vector2(m, 0), p + Vector2(0, m), p + Vector2(-m, 0),
		]), Color(1.0, 0.85, 0.2))

	# Player arrow: forward is -Z in the world, which is up on the map.
	var pc := _to_px(_player_xz)
	var k := 1.0 if not full else 1.5
	var dir := Vector2(-sin(_yaw), -cos(_yaw))
	var perp := Vector2(-dir.y, dir.x)
	var tip := pc + dir * 16.0 * k
	var base := pc - dir * 9.0 * k
	draw_colored_polygon(PackedVector2Array([tip, base + perp * 10.0 * k, base - perp * 10.0 * k]), Color(1, 1, 1))


func _gui_input(event: InputEvent) -> void:
	var pos := Vector2.ZERO
	var pressed := false
	var t := event as InputEventScreenTouch
	var m := event as InputEventMouseButton
	if t != null and t.pressed:
		pressed = true
		pos = t.position
	elif m != null and m.pressed and m.button_index == MOUSE_BUTTON_LEFT:
		pressed = true
		pos = m.position
	if not pressed:
		return
	var local := pos - _center()
	if local.length() > _side() * 0.5:
		if full:
			accept_event()
		return
	target_set.emit(local / _side() * _world_size)
	accept_event()
