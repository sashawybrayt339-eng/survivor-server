extends PanelContainer

const ItemDbScript = preload("res://scripts/item_db.gd")
const ThemeScript = preload("res://scripts/ui_theme.gd")

signal close_requested

var _items: Array = []
var _list: GridContainer
var _message: Label


func _ready() -> void:
	visible = false
	set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	offset_left = -280
	offset_right = 280
	offset_top = -330
	offset_bottom = 330
	add_theme_stylebox_override("panel", ThemeScript.make_style(ThemeScript.COLOR_PANEL, ThemeScript.COLOR_BORDER, 2, 30))

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 16)
	add_child(column)

	var header := HBoxContainer.new()
	column.add_child(header)
	var title := Label.new()
	title.text = "بک‌پک کدو تنبل"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.add_theme_font_size_override("font_size", 42)
	header.add_child(title)
	var close_button := ThemeScript.make_small_button("×")
	close_button.pressed.connect(func() -> void: close_requested.emit())
	header.add_child(close_button)

	var hint := Label.new()
	hint.text = "روی هر آیتم بزن تا به بک‌پک خودت اضافه شود"
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint.add_theme_font_size_override("font_size", 26)
	hint.add_theme_color_override("font_color", ThemeScript.COLOR_MUTED)
	column.add_child(hint)

	_list = GridContainer.new()
	_list.columns = 2
	_list.add_theme_constant_override("h_separation", 14)
	_list.add_theme_constant_override("v_separation", 14)
	column.add_child(_list)

	_message = Label.new()
	_message.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_message.add_theme_font_size_override("font_size", 26)
	_message.add_theme_color_override("font_color", ThemeScript.COLOR_GOLD)
	column.add_child(_message)


# items is the pumpkin's loot array, taken by reference so picked items disappear from it.
func open(items: Array) -> void:
	_items = items
	_message.text = ""
	visible = true
	_rebuild()


func _rebuild() -> void:
	for child in _list.get_children():
		child.queue_free()
	if _items.is_empty():
		_message.text = "این کدو تنبل خالی شد."
		return
	for item_id in _items:
		var data := ItemDbScript.get_item(item_id)
		var button := Button.new()
		button.custom_minimum_size = Vector2(250, 190)
		button.text = data["name"]
		button.icon = ItemDbScript.icon(item_id)
		button.expand_icon = true
		button.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
		button.vertical_icon_alignment = VERTICAL_ALIGNMENT_TOP
		button.add_theme_font_size_override("font_size", 26)
		button.add_theme_color_override("font_color", ThemeScript.COLOR_TEXT)
		button.add_theme_stylebox_override("normal", ThemeScript.make_style(Color(0.1, 0.12, 0.1), ThemeScript.COLOR_BORDER, 2, 20))
		button.add_theme_stylebox_override("hover", ThemeScript.make_style(Color(0.14, 0.18, 0.13), ThemeScript.COLOR_ACCENT, 2, 20))
		button.add_theme_stylebox_override("pressed", ThemeScript.make_style(Color(0.14, 0.18, 0.13), ThemeScript.COLOR_ACCENT, 2, 20))
		button.pressed.connect(_on_item_pressed.bind(item_id))
		_list.add_child(button)


func _on_item_pressed(item_id: String) -> void:
	if Store.add_item(item_id):
		_items.erase(item_id)
		_message.text = "به بک‌پک اضافه شد"
		_rebuild()
	else:
		_message.text = "بک‌پک پر است"
