extends RefCounted

# Rolling, rocky land with roads, a sandy beach and open sea around the map.
# height_at() is the single source of truth: terrain mesh, trees, grass, pumpkins,
# the minimap and the spawn point all use it.

const SIZE := 1000.0
const CELLS := 200
const HILL_HEIGHT := 20.0
const CRAG_HEIGHT := 8.0
const ROCK_HEIGHT := 2.2
const SEA_LEVEL := -1.5
const SEA_FLOOR := -4.0
const BEACH_LEVEL := 0.8
const SPAWN_RADIUS := 385.0

const ROAD_RES := 512
const ROAD_HALF_WIDTH := 6.0
const ROADS := [
	[Vector2(-395, -95), Vector2(-260, -40), Vector2(-40, 60), Vector2(180, -60), Vector2(360, 60)],
	[Vector2(-90, 360), Vector2(-60, 200), Vector2(20, 0), Vector2(120, -220), Vector2(150, -340)],
	[Vector2(-380, 240), Vector2(-200, 260), Vector2(-40, 60)],
]

static var _n_hill: FastNoiseLite = null
static var _n_crag: FastNoiseLite = null
static var _n_rock: FastNoiseLite = null
static var _road_mask: PackedFloat32Array = PackedFloat32Array()


static func _setup() -> void:
	if _n_hill != null:
		return
	_n_hill = FastNoiseLite.new()
	_n_hill.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_n_hill.frequency = 0.0042
	_n_hill.fractal_octaves = 3
	_n_hill.seed = 1337
	_n_crag = FastNoiseLite.new()
	_n_crag.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_n_crag.frequency = 0.012
	_n_crag.seed = 42
	_n_rock = FastNoiseLite.new()
	_n_rock.noise_type = FastNoiseLite.TYPE_SIMPLEX
	_n_rock.frequency = 0.09
	_n_rock.seed = 7


# Rasterises the roads into a mask once (roads are straight segments of a few lines).
static func _build_roads() -> void:
	if _road_mask.size() == ROAD_RES * ROAD_RES:
		return
	_road_mask = PackedFloat32Array()
	_road_mask.resize(ROAD_RES * ROAD_RES)
	var cell := SIZE / float(ROAD_RES)
	var half := SIZE * 0.5
	var rad := int(ceil(ROAD_HALF_WIDTH / cell))
	for road in ROADS:
		for i in range(road.size() - 1):
			var a: Vector2 = road[i]
			var b: Vector2 = road[i + 1]
			var steps := int(a.distance_to(b) / (cell * 0.5)) + 1
			for s in range(steps + 1):
				var p := a.lerp(b, float(s) / float(steps))
				var cx := int(floor((p.x + half) / cell))
				var cz := int(floor((p.y + half) / cell))
				for dz in range(-rad, rad + 1):
					for dx in range(-rad, rad + 1):
						var ix := cx + dx
						var iz := cz + dz
						if ix < 0 or iz < 0 or ix >= ROAD_RES or iz >= ROAD_RES:
							continue
						var d := Vector2(float(dx), float(dz)).length() * cell
						if d <= ROAD_HALF_WIDTH:
							_road_mask[iz * ROAD_RES + ix] = 1.0


# 0 = not road, 1 = road.
static func road_weight(x: float, z: float) -> float:
	_build_roads()
	var cell := SIZE / float(ROAD_RES)
	var ix := int(floor((x + SIZE * 0.5) / cell))
	var iz := int(floor((z + SIZE * 0.5) / cell))
	if ix < 0 or iz < 0 or ix >= ROAD_RES or iz >= ROAD_RES:
		return 0.0
	return _road_mask[iz * ROAD_RES + ix]


static func height_at(x: float, z: float) -> float:
	_setup()
	var r := sqrt(x * x + z * z)
	var hill := _n_hill.get_noise_2d(x, z) * HILL_HEIGHT
	var crag := pow(1.0 - absf(_n_crag.get_noise_2d(x + 300.0, z - 200.0)), 2.0) * CRAG_HEIGHT
	var rock := _n_rock.get_noise_2d(x, z) * ROCK_HEIGHT * (0.4 + absf(_n_hill.get_noise_2d(x, z)))
	var h := (hill + crag + rock) * smoothstep(4.0, 24.0, r)
	# Roads are gentler than the land around them.
	h = lerpf(h, h * 0.25, road_weight(x, z))
	# Sandy beach ring, then the land drops into the sea.
	var beach := smoothstep(355.0, 372.0, r) * (1.0 - smoothstep(398.0, 412.0, r))
	h = lerpf(h, BEACH_LEVEL, beach)
	h = lerpf(h, SEA_FLOOR, smoothstep(405.0, 445.0, r))
	return h


# Player spawns on the beach, never in the water.
static func spawn_point() -> Vector3:
	var x := 0.0
	var z := -SPAWN_RADIUS
	return Vector3(x, height_at(x, z) + 0.3, z)


static func build_mesh() -> ArrayMesh:
	_build_roads()
	var n := CELLS + 1
	var step := SIZE / float(CELLS)
	var half := SIZE * 0.5
	var verts := PackedVector3Array()
	var normals := PackedVector3Array()
	var uvs := PackedVector2Array()
	var colors := PackedColorArray()
	for j in range(n):
		for i in range(n):
			var x := -half + float(i) * step
			var z := -half + float(j) * step
			verts.append(Vector3(x, height_at(x, z), z))
			var dx := height_at(x + step, z) - height_at(x - step, z)
			var dz := height_at(x, z + step) - height_at(x, z - step)
			normals.append(Vector3(-dx, 2.0 * step, -dz).normalized())
			uvs.append(Vector2(x, z) * 0.1)
			colors.append(Color(1, 1, 1).lerp(Color(0.38, 0.36, 0.33), road_weight(x, z)))
	var indices := PackedInt32Array()
	for j in range(CELLS):
		for i in range(CELLS):
			var a := j * n + i
			var b := a + 1
			var d := a + n
			var c := d + 1
			indices.append(a)
			indices.append(c)
			indices.append(b)
			indices.append(a)
			indices.append(d)
			indices.append(c)
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_COLOR] = colors
	arrays[Mesh.ARRAY_INDEX] = indices
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return mesh


# Circular map of the whole world: green land, grey roads, blue sea and beach.
static func build_minimap(res: int = 256) -> ImageTexture:
	var img := Image.create(res, res, false, Image.FORMAT_RGBA8)
	var half := SIZE * 0.5
	var rr := float(res) * 0.5
	for v in range(res):
		for u in range(res):
			var dx := float(u) + 0.5 - rr
			var dy := float(v) + 0.5 - rr
			if dx * dx + dy * dy > rr * rr:
				img.set_pixel(u, v, Color(0, 0, 0, 0))
				continue
			var x := (float(u) + 0.5) / float(res) * SIZE - half
			var z := (float(v) + 0.5) / float(res) * SIZE - half
			var h := height_at(x, z)
			var col: Color
			if h < SEA_LEVEL:
				col = Color(0.12, 0.3, 0.45).lerp(Color(0.2, 0.45, 0.6), clampf((h + 4.0) / 2.5, 0.0, 1.0))
			else:
				var k := clampf((h + 10.0) / 45.0, 0.0, 1.0)
				col = Color(0.12, 0.32, 0.12).lerp(Color(0.6, 0.9, 0.4), k)
				col = col.lerp(Color(0.4, 0.38, 0.35), road_weight(x, z) * 0.9)
			img.set_pixel(u, v, col)
	return ImageTexture.create_from_image(img)
