extends Node

# Connection quality for the Wi-Fi badge. Measures round-trip time to the Render server.
signal quality_changed(level: int, ping_ms: int)

# Replace with your Render address after deploying survivor-server.
const SERVER_URL := "https://survivor-servers.onrender.com"
const CHECK_EVERY := 5.0

const LEVEL_UNKNOWN := 0
const LEVEL_WEAK := 1
const LEVEL_MEDIUM := 2
const LEVEL_GREAT := 3

var level := LEVEL_UNKNOWN
var ping_ms := -1
var _http: HTTPRequest
var _timer := 0.0
var _busy := false
var _sent_at := 0
var _samples: Array[int] = []


func _ready() -> void:
	_http = HTTPRequest.new()
	_http.timeout = 8.0
	add_child(_http)
	_http.request_completed.connect(_on_done)


func _process(delta: float) -> void:
	_timer -= delta
	if _timer <= 0.0 and not _busy:
		_check()


func _check() -> void:
	_timer = CHECK_EVERY
	_busy = true
	_sent_at = Time.get_ticks_msec()
	if _http.request(SERVER_URL + "/health") != OK:
		_busy = false
		_samples.clear()
		_set_level(LEVEL_WEAK, -1)


func _on_done(result: int, code: int, _headers: PackedStringArray, _body: PackedByteArray) -> void:
	_busy = false
	if result != HTTPRequest.RESULT_SUCCESS or code != 200:
		_samples.clear()
		_set_level(LEVEL_WEAK, -1)
		return
	_samples.append(Time.get_ticks_msec() - _sent_at)
	if _samples.size() > 3:
		_samples.pop_front()
	var sum := 0
	for v in _samples:
		sum += v
	var avg := sum / _samples.size()
	var lvl := LEVEL_WEAK
	if avg < 150:
		lvl = LEVEL_GREAT
	elif avg < 350:
		lvl = LEVEL_MEDIUM
	_set_level(lvl, avg)


func _set_level(lvl: int, ms: int) -> void:
	level = lvl
	ping_ms = ms
	quality_changed.emit(lvl, ms)
