extends Node

# BugGuard (autoload) - سیستم تشخیص و ترمیم خودکار باگ
#
# 1) همهٔ خطاهای اسکریپت/شیدر را می‌گیرد و در user://bug_log.txt ذخیره می‌کند
#    (دکمهٔ BUG روی صفحه، گزارش را نشان می‌دهد و می‌شود کپی‌اش کرد).
# 2) قبل از شروع بازی همهٔ اسکریپت‌ها را چک می‌کند (preflight)؛ اگر یکی کامپایل
#    نشود، به‌جای صفحهٔ خاکستری، اسم فایل خراب را نشان می‌دهد.
# 3) ترمیم خودکار در حین بازی: HUD گم‌شده، کنترل قفل‌شده، دوربین گم‌شده،
#    لودینگ گیرکرده، افتادن از زمین و FPS پایین (کیفیت خودکار کم می‌شود).
#
# این اسکریپت عمداً به هیچ اسکریپت دیگری وابسته نیست (فقط با گروه‌ها و
# duck-typing کار می‌کند) تا خودش باعث خرابی بازی نشود.

const LOG_PATH := "user://bug_log.txt"
const GAME_SCENE_PATH := "res://scenes/game.tscn"
const MENU_SCENE_PATH := "res://scenes/main_menu.tscn"
const LOGGER_SCRIPT := "res://scripts/bug_logger.gd"
const MAX_UNIQUE_ERRORS := 60
const SCAN_INTERVAL := 0.5
const LOADING_BACKUP_SECONDS := 40.0
const LOW_FPS := 24.0
const LOW_FPS_SECONDS := 4.0
const MAX_QUALITY_LEVEL := 2
const SHOW_BADGE := true

const REQUIRED_SCRIPTS: Array[String] = [
	"res://scripts/store.gd",
	"res://scripts/ui_theme.gd",
	"res://scripts/item_db.gd",
	"res://scripts/procedural.gd",
	"res://scripts/terrain.gd",
	"res://scripts/minimap.gd",
	"res://scripts/wifi_icon.gd",
	"res://scripts/net.gd",
	"res://scripts/virtual_joystick.gd",
	"res://scripts/backpack_panel.gd",
	"res://scripts/loot_panel.gd",
	"res://scripts/pumpkin.gd",
	"res://scripts/axe_tool.gd",
	"res://scripts/player.gd",
	"res://scripts/game_hud.gd",
	"res://scripts/game_world.gd",
	"res://scripts/main_menu.gd",
	"res://scripts/shop.gd",
]

var error_count := 0
var heal_count := 0
var quality_level := 0

var _mutex := Mutex.new()
var _pending: Array[String] = []
var _unique: Dictionary = {}      # message -> times seen
var _order: Array[String] = []    # unique messages in first-seen order
var _heals: Array[String] = []
var _logger: RefCounted = null

var _scan_timer := 0.0
var _last_scene: Node = null
var _scene_time := 0.0
var _scene_checked := false
var _low_fps_time := 0.0

var _layer: CanvasLayer
var _badge: Button
var _panel: PanelContainer
var _text: Label
var _title: Label
var _menu_button: Button


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_install_logger()
	_build_ui()


# ---------------------------------------------------------------- public API

# Returns the list of scripts that failed to compile. Empty array = all good.
func preflight() -> PackedStringArray:
	var bad := PackedStringArray()
	for path in REQUIRED_SCRIPTS:
		if not ResourceLoader.exists(path):
			bad.append(path.get_file() + " (پیدا نشد)")
			continue
		var script := load(path) as GDScript
		if script == null or not script.can_instantiate():
			bad.append(path.get_file())
	if not ResourceLoader.exists(GAME_SCENE_PATH):
		bad.append("game.tscn (پیدا نشد)")
	_flush_pending()
	return bad


func report(text: String) -> void:
	_push(text)


func show_report(headline: String = "") -> void:
	_flush_pending()
	_title.text = headline if headline != "" else "گزارش خطاها"
	_text.text = _build_report(false)
	_menu_button.visible = get_tree().current_scene != null and get_tree().current_scene.scene_file_path != MENU_SCENE_PATH
	_panel.visible = true


# ---------------------------------------------------------------- main loop

func _process(delta: float) -> void:
	_flush_pending()
	_scan_timer -= delta
	if _scan_timer > 0.0:
		return
	_scan_timer = SCAN_INTERVAL

	var scene := get_tree().current_scene
	if scene != _last_scene:
		_last_scene = scene
		_scene_time = 0.0
		_scene_checked = false
		_low_fps_time = 0.0
	_scene_time += SCAN_INTERVAL
	if scene == null:
		return

	if not _scene_checked and _scene_time >= 0.5:
		_scene_checked = true
		_check_scene_script(scene)

	if scene.scene_file_path == GAME_SCENE_PATH and scene.get_script() != null:
		_heal_game(scene)


func _check_scene_script(scene: Node) -> void:
	if scene.scene_file_path == GAME_SCENE_PATH and scene.get_script() == null:
		_push("game.tscn بدون اسکریپت لود شد (اسکریپت game_world.gd کامپایل نشده)")
		var bad := preflight()
		var names := ", ".join(bad) if not bad.is_empty() else "game_world.gd"
		show_report("بازی لود نشد؛ فایل خراب: " + names)


func _heal_game(scene: Node) -> void:
	var loaded = scene.get("_loaded")
	if loaded == null:
		return

	# Loading stuck for too long -> force finish (backup for the in-game watchdog).
	if not loaded:
		if _scene_time >= LOADING_BACKUP_SECONDS and scene.has_method("_finish_loading"):
			scene.call("_finish_loading")
			_heal("لودینگ گیر کرده بود؛ اجباری تمام شد")
		return

	# Loading overlay still on screen after loading finished.
	var overlay = scene.get("_overlay")
	if overlay is CanvasLayer and overlay.visible:
		overlay.visible = false
		_heal("صفحهٔ لودینگ بعد از لود هنوز باز بود؛ بسته شد")

	# HUD / buttons hidden after loading.
	for hud in get_tree().get_nodes_in_group("hud"):
		if hud is CanvasLayer and not hud.visible:
			hud.visible = true
			_heal("HUD و دکمه‌ها مخفی شده بودند؛ دوباره نمایش داده شدند")

	# Player-related checks.
	var players := get_tree().get_nodes_in_group("player")
	for player in players:
		if player is CharacterBody3D:
			if player.global_position.y < -20.0 or not player.global_position.is_finite():
				player.global_position = Vector3(0.0, 0.5, 0.0)
				player.velocity = Vector3.ZERO
				_heal("بازیکن از زمین افتاده بود؛ برگشت به نقطهٔ شروع")
			var panel_open := false
			for hud in get_tree().get_nodes_in_group("hud"):
				if hud.has_method("panel_open"):
					panel_open = hud.call("panel_open")
			if not panel_open and player.get("control_enabled") == false:
				player.set("control_enabled", true)
				_heal("کنترل بازیکن قفل مانده بود؛ آزاد شد")

	# Camera lost.
	if get_viewport().get_camera_3d() == null and not players.is_empty():
		var cam := _find_camera(players[0])
		if cam != null:
			cam.make_current()
			_heal("دوربین فعال نبود؛ دوباره فعال شد")

	_auto_quality(scene)


func _find_camera(node: Node) -> Camera3D:
	if node is Camera3D:
		return node as Camera3D
	for child in node.get_children():
		var found := _find_camera(child)
		if found != null:
			return found
	return null


# Lower the graphics level when FPS stays low (never raises it back, to avoid flicker).
func _auto_quality(scene: Node) -> void:
	if quality_level >= MAX_QUALITY_LEVEL or not scene.has_method("apply_quality"):
		return
	var fps := Engine.get_frames_per_second()
	if fps > 0.0 and fps < LOW_FPS:
		_low_fps_time += SCAN_INTERVAL
	else:
		_low_fps_time = 0.0
	if _low_fps_time >= LOW_FPS_SECONDS:
		_low_fps_time = 0.0
		quality_level += 1
		scene.call("apply_quality", quality_level)
		_heal("FPS پایین بود (%d)؛ کیفیت گرافیک به سطح %d کم شد" % [int(fps), quality_level])


# ---------------------------------------------------------------- bookkeeping

func _heal(text: String) -> void:
	heal_count += 1
	_heals.append(text)
	if _heals.size() > 30:
		_heals.pop_front()
	_push("[HEAL] " + text)


# Thread-safe: the engine logger may call this from any thread.
func _push_from_logger(text: String) -> void:
	_mutex.lock()
	if _pending.size() < 200:
		_pending.append(text)
	_mutex.unlock()


func _push(text: String) -> void:
	_push_from_logger(text)


func _flush_pending() -> void:
	_mutex.lock()
	var batch := _pending.duplicate()
	_pending.clear()
	_mutex.unlock()
	if batch.is_empty():
		return
	for text in batch:
		if _unique.has(text):
			_unique[text] += 1
			continue
		if _order.size() >= MAX_UNIQUE_ERRORS:
			continue
		_unique[text] = 1
		_order.append(text)
		if not text.begins_with("[HEAL]"):
			error_count += 1
	_save_log()
	_refresh_badge()


func _save_log() -> void:
	var file := FileAccess.open(LOG_PATH, FileAccess.WRITE)
	if file != null:
		file.store_string(_build_report(true))
		file.close()


func _build_report(full: bool) -> String:
	var lines: PackedStringArray = []
	lines.append("Godot %s | %s | FPS %d | quality %d" % [
		Engine.get_version_info().get("string", "?"), OS.get_name(),
		int(Engine.get_frames_per_second()), quality_level])
	lines.append("خطا: %d | ترمیم خودکار: %d" % [error_count, heal_count])
	lines.append("")
	var shown := 0
	for text in _order:
		if text.begins_with("[HEAL]"):
			continue
		lines.append("(%d×) %s" % [_unique[text], text])
		shown += 1
		if not full and shown >= 8:
			lines.append("...")
			break
	if not _heals.is_empty():
		lines.append("")
		lines.append("ترمیم‌ها:")
		for text in _heals:
			lines.append("- " + text)
	return "\n".join(lines)


func _install_logger() -> void:
	# Logger exists only in newer Godot versions; skip silently on older ones.
	if not ClassDB.class_exists("Logger") or not ClassDB.class_exists("ScriptBacktrace"):
		return
	if not ResourceLoader.exists(LOGGER_SCRIPT):
		return
	var script := load(LOGGER_SCRIPT) as GDScript
	if script == null or not script.can_instantiate():
		return
	_logger = script.new()
	_logger.set("sink", self)
	OS.call("add_logger", _logger)


# ---------------------------------------------------------------- UI

func _build_ui() -> void:
	_layer = CanvasLayer.new()
	_layer.layer = 200
	_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(_layer)

	_badge = Button.new()
	_badge.visible = false
	_badge.text = "BUG"
	_badge.layout_direction = Control.LAYOUT_DIRECTION_LTR
	_badge.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	_badge.offset_left = -200
	_badge.offset_right = -30
	_badge.offset_top = 90
	_badge.offset_bottom = 146
	_badge.add_theme_font_size_override("font_size", 26)
	_badge.add_theme_color_override("font_color", Color.WHITE)
	_badge.add_theme_stylebox_override("normal", _box(Color(0.7, 0.12, 0.1, 0.85), 16))
	_badge.add_theme_stylebox_override("pressed", _box(Color(0.5, 0.08, 0.06, 0.95), 16))
	_badge.add_theme_stylebox_override("hover", _box(Color(0.8, 0.16, 0.12, 0.9), 16))
	_badge.pressed.connect(func() -> void: show_report())
	_layer.add_child(_badge)

	_panel = PanelContainer.new()
	_panel.visible = false
	_panel.layout_direction = Control.LAYOUT_DIRECTION_LTR
	_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_panel.offset_left = 30
	_panel.offset_right = -30
	_panel.offset_top = 80
	_panel.offset_bottom = -80
	_panel.add_theme_stylebox_override("panel", _box(Color(0.05, 0.06, 0.05, 0.97), 28))
	_layer.add_child(_panel)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 16)
	_panel.add_child(column)

	_title = Label.new()
	_title.text = "گزارش خطاها"
	_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_title.add_theme_font_size_override("font_size", 34)
	_title.add_theme_color_override("font_color", Color(1.0, 0.82, 0.38))
	column.add_child(_title)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	column.add_child(scroll)

	_text = Label.new()
	_text.autowrap_mode = TextServer.AUTOWRAP_ARBITRARY
	_text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_text.add_theme_font_size_override("font_size", 22)
	_text.add_theme_color_override("font_color", Color(0.92, 0.94, 0.9))
	scroll.add_child(_text)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	column.add_child(row)
	row.add_child(_make_button("کپی گزارش", func() -> void: DisplayServer.clipboard_set(_build_report(true))))
	row.add_child(_make_button("بستن", func() -> void: _panel.visible = false))
	_menu_button = _make_button("منوی اصلی", _go_menu)
	row.add_child(_menu_button)


func _make_button(label: String, action: Callable) -> Button:
	var button := Button.new()
	button.text = label
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.custom_minimum_size = Vector2(0, 80)
	button.add_theme_font_size_override("font_size", 28)
	button.add_theme_color_override("font_color", Color.WHITE)
	button.add_theme_stylebox_override("normal", _box(Color(0.2, 0.5, 0.15), 18))
	button.add_theme_stylebox_override("pressed", _box(Color(0.14, 0.36, 0.1), 18))
	button.add_theme_stylebox_override("hover", _box(Color(0.25, 0.58, 0.18), 18))
	button.pressed.connect(action)
	return button


func _go_menu() -> void:
	_panel.visible = false
	get_tree().change_scene_to_file(MENU_SCENE_PATH)


func _box(color: Color, radius: int) -> StyleBoxFlat:
	var box := StyleBoxFlat.new()
	box.bg_color = color
	box.set_corner_radius_all(radius)
	box.content_margin_left = 22
	box.content_margin_right = 22
	box.content_margin_top = 14
	box.content_margin_bottom = 14
	return box


func _refresh_badge() -> void:
	if not SHOW_BADGE or _badge == null:
		return
	_badge.visible = error_count > 0
	_badge.text = "BUG %d" % error_count
