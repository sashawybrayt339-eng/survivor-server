extends CharacterBody3D

const WALK_SPEED := 4.2
const GRAVITY := 12.0
const LOOK_SENSITIVITY := 0.004
const EYE_HEIGHT := 1.6
const TerrainScript = preload("res://scripts/terrain.gd")

var move_input := Vector2.ZERO
var control_enabled := true
var _head: Node3D
var _camera: Camera3D
var _pitch := 0.0
var _bob_time := 0.0
var _bob_amount := 0.0


func _ready() -> void:
	add_to_group("player")
	var shape := CapsuleShape3D.new()
	shape.radius = 0.35
	shape.height = 1.8
	var collider := CollisionShape3D.new()
	collider.shape = shape
	collider.position.y = 0.9
	add_child(collider)

	_head = Node3D.new()
	_head.position.y = 1.6
	add_child(_head)

	_camera = Camera3D.new()
	_camera.fov = 72.0
	_camera.near = 0.05
	_camera.far = 400.0
	_camera.current = true
	_head.add_child(_camera)


func make_camera_current() -> void:
	_camera.current = true


func get_camera() -> Camera3D:
	return _camera


func look(relative: Vector2) -> void:
	if not control_enabled:
		return
	rotate_y(-relative.x * LOOK_SENSITIVITY)
	_pitch = clamp(_pitch - relative.y * LOOK_SENSITIVITY, -1.3, 1.3)
	_head.rotation.x = _pitch


func _physics_process(delta: float) -> void:
	if global_position.y < -20.0 or not global_position.is_finite():
		# Fell through the world (or NaN): put the player back at the start.
		global_position = TerrainScript.spawn_point()
		velocity = Vector3.ZERO
	if is_on_floor():
		velocity.y = 0.0
	else:
		velocity.y -= GRAVITY * delta
	var input := move_input if control_enabled else Vector2.ZERO
	var direction := transform.basis * Vector3(input.x, 0.0, input.y)
	direction.y = 0.0
	velocity.x = direction.x * WALK_SPEED
	velocity.z = direction.z * WALK_SPEED
	move_and_slide()
	var speed := Vector2(velocity.x, velocity.z).length()
	var target_amount := clampf(speed / WALK_SPEED, 0.0, 1.0) if is_on_floor() else 0.0
	_bob_amount = lerpf(_bob_amount, target_amount, clampf(delta * 8.0, 0.0, 1.0))
	_bob_time += delta * (4.0 + speed * 1.2)
	_head.position.y = EYE_HEIGHT + sin(_bob_time * 2.0) * 0.05 * _bob_amount
	_head.position.x = cos(_bob_time) * 0.03 * _bob_amount
