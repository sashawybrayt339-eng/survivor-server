extends RefCounted

# One source of truth for every button, panel and label so the UI stays consistent.
const FONT_PATH := "res://assets/fonts/Vazirmatn-Regular.ttf"
const BUTTON_WIDTH := 560.0
const BUTTON_HEIGHT := 104.0
const BUTTON_FONT := 38
const RADIUS := 24

const COLOR_PANEL := Color(0.08, 0.1, 0.085, 0.97)
const COLOR_BORDER := Color(0.2, 0.28, 0.22)
const COLOR_ACCENT := Color(0.42, 0.85, 0.28)
const COLOR_ACCENT_DARK := Color(0.2, 0.5, 0.15)
const COLOR_SECONDARY := Color(0.14, 0.17, 0.15)
const COLOR_DISABLED := Color(0.16, 0.18, 0.17)
const COLOR_TEXT := Color(0.95, 0.96, 0.93)
const COLOR_MUTED := Color(0.62, 0.68, 0.62)
const COLOR_GOLD := Color(1.0, 0.82, 0.38)


static func build_theme() -> Theme:
	var theme := Theme.new()
	if ResourceLoader.exists(FONT_PATH):
		theme.default_font = load(FONT_PATH)
	theme.default_font_size = 34
	theme.set_color("font_color", "Label", COLOR_TEXT)
	return theme


static func make_style(bg: Color, border: Color = Color.TRANSPARENT, border_width: int = 0, radius: int = RADIUS) -> StyleBoxFlat:
	var box := StyleBoxFlat.new()
	box.bg_color = bg
	box.set_corner_radius_all(radius)
	box.set_border_width_all(border_width)
	box.border_color = border
	box.content_margin_left = 22
	box.content_margin_right = 22
	box.content_margin_top = 12
	box.content_margin_bottom = 12
	return box


# kind: "primary" (green action) or "secondary" (neutral).
static func make_button(text: String, kind: String = "secondary") -> Button:
	var button := Button.new()
	button.text = text
	button.custom_minimum_size = Vector2(BUTTON_WIDTH, BUTTON_HEIGHT)
	button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	button.add_theme_font_size_override("font_size", BUTTON_FONT)
	button.add_theme_color_override("font_color", COLOR_TEXT)
	button.add_theme_color_override("font_hover_color", COLOR_TEXT)
	button.add_theme_color_override("font_pressed_color", COLOR_TEXT)
	button.add_theme_color_override("font_disabled_color", COLOR_MUTED)
	var base := COLOR_ACCENT_DARK if kind == "primary" else COLOR_SECONDARY
	var border := COLOR_ACCENT if kind == "primary" else COLOR_BORDER
	button.add_theme_stylebox_override("normal", make_style(base, border, 2))
	button.add_theme_stylebox_override("hover", make_style(base.lightened(0.08), border, 2))
	button.add_theme_stylebox_override("pressed", make_style(base.darkened(0.2), border, 2))
	button.add_theme_stylebox_override("focus", make_style(base, border, 2))
	button.add_theme_stylebox_override("disabled", make_style(COLOR_DISABLED, COLOR_BORDER, 2))
	return button


static func make_small_button(text: String) -> Button:
	var button := make_button(text, "secondary")
	button.custom_minimum_size = Vector2(120, 72)
	button.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	button.add_theme_font_size_override("font_size", 32)
	return button


static func background_texture() -> GradientTexture2D:
	var grad := Gradient.new()
	grad.colors = PackedColorArray([Color(0.1, 0.16, 0.08), Color(0.03, 0.04, 0.03)])
	grad.offsets = PackedFloat32Array([0.0, 1.0])
	var tex := GradientTexture2D.new()
	tex.gradient = grad
	tex.fill = GradientTexture2D.FILL_LINEAR
	tex.fill_from = Vector2(0.5, 0.0)
	tex.fill_to = Vector2(0.5, 1.0)
	tex.width = 16
	tex.height = 256
	return tex
