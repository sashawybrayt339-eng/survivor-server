extends Control

# Wi-Fi badge: red = weak, yellow = medium, green = great, grey = unknown.
var _level := 0


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	Net.quality_changed.connect(_on_quality)
	_level = Net.level
	queue_redraw()


func _on_quality(lvl: int, _ms: int) -> void:
	_level = lvl
	queue_redraw()


func _draw() -> void:
	var colors: Array[Color] = [Color(0.5, 0.5, 0.5), Color(1.0, 0.25, 0.2), Color(1.0, 0.85, 0.2), Color(0.3, 1.0, 0.35)]
	var on: Color = colors[clampi(_level, 0, 3)]
	var heights: Array[float] = [14.0, 24.0, 34.0]
	for i in range(3):
		var bh: float = heights[i]
		var x := 6.0 + float(i) * 20.0
		var active := i < _level
		draw_rect(Rect2(x, 40.0 - bh, 14.0, bh), on if active else Color(0.3, 0.3, 0.3, 0.6))
