extends Logger

# Receives every engine error/script error and forwards it to BugGuard.
# Loaded only when the running Godot version has the Logger class (4.5+).
# The engine can call this from any thread, so it only does a thread-safe push.

var sink: Object = null


func _log_error(function: String, file: String, line: int, code: String, rationale: String, _editor_notify: bool, error_type: int, _script_backtraces: Array[ScriptBacktrace]) -> void:
	if error_type == 1:
		return # plain warnings are ignored
	if sink == null or not is_instance_valid(sink):
		return
	var message := rationale if rationale != "" else code
	var kind := "SCRIPT" if error_type == 2 else ("SHADER" if error_type == 3 else "ERROR")
	var text := "[%s] %s  (%s:%d %s)" % [kind, message, file.get_file(), line, function]
	sink.call("_push_from_logger", text)
