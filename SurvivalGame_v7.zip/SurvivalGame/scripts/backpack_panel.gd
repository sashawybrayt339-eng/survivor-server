extends PanelContainer

const ItemDbScript = preload("res://scripts/item_db.gd")
const ThemeScript = preload("res://scripts/ui_theme.gd")

signal item_used(index: int)
signal close_requested

const COLUMNS := 4
const SLOT_SIZE := 118.0
const INK := Color(0.13, 0.15, 0.13)
const INK_SOFT := Color(0.42, 0.46, 0.42)
const CARD := Color(0.96, 0.97, 0.96)

var _count_pill: Label
var _grid: GridContainer
var _slots: Array[Button] = []
var _detail: PanelContainer
var _icon: TextureRect
var _name_label: Label
var _desc_label: Label
var _heal_chip: Label
var _empty_label: Label
var _use_button: Button
var _selected := -1


func _ready() -> void:
	visible = false
	set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	offset_left = -330
	offset_right = 330
	offset_top = -500
	offset_bottom = 500
	add_theme_stylebox_override("panel", _card_style())
	add_theme_color_override("font_color", INK)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 20)
	add_child(column)

	# Header: title, slot counter pill, round close button
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 14)
	column.add_child(header)
	var title := Label.new()
	title.text = "بک‌پک"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.add_theme_font_size_override("font_size", 50)
	header.add_child(title)
	_count_pill = Label.new()
	_count_pill.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_count_pill.custom_minimum_size = Vector2(130, 58)
	_count_pill.add_theme_font_size_override("font_size", 28)
	_count_pill.add_theme_color_override("font_color", Color.WHITE)
	_count_pill.add_theme_stylebox_override("normal", ThemeScript.make_style(ThemeScript.COLOR_ACCENT_DARK, Color.TRANSPARENT, 0, 29))
	header.add_child(_count_pill)
	var close_button := Button.new()
	close_button.text = "×"
	close_button.custom_minimum_size = Vector2(58, 58)
	close_button.add_theme_font_size_override("font_size", 36)
	close_button.add_theme_color_override("font_color", INK)
	close_button.add_theme_stylebox_override("normal", ThemeScript.make_style(Color(0.9, 0.91, 0.9), Color.TRANSPARENT, 0, 29))
	close_button.add_theme_stylebox_override("hover", ThemeScript.make_style(Color(0.84, 0.86, 0.84), Color.TRANSPARENT, 0, 29))
	close_button.add_theme_stylebox_override("pressed", ThemeScript.make_style(Color(0.78, 0.8, 0.78), Color.TRANSPARENT, 0, 29))
	close_button.pressed.connect(func() -> void: close_requested.emit())
	header.add_child(close_button)

	var divider := ColorRect.new()
	divider.color = Color(0.85, 0.87, 0.85)
	divider.custom_minimum_size = Vector2(0, 2)
	column.add_child(divider)

	# Slot grid: square cells that touch each other
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, 470)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	column.add_child(scroll)
	_grid = GridContainer.new()
	_grid.columns = COLUMNS
	_grid.add_theme_constant_override("h_separation", 0)
	_grid.add_theme_constant_override("v_separation", 0)
	scroll.add_child(_grid)
	for i in range(Store.MAX_SLOTS + 1):
		var slot := Button.new()
		slot.custom_minimum_size = Vector2(SLOT_SIZE, SLOT_SIZE)
		slot.expand_icon = true
		slot.add_theme_stylebox_override("normal", _slot_style(Color.WHITE, Color(0.8, 0.82, 0.8), 1))
		slot.add_theme_stylebox_override("hover", _slot_style(Color(0.95, 0.98, 0.95), Color(0.8, 0.82, 0.8), 1))
		slot.add_theme_stylebox_override("pressed", _slot_style(Color(0.9, 0.97, 0.88), ThemeScript.COLOR_ACCENT, 2))
		slot.add_theme_stylebox_override("focus", _slot_style(Color.WHITE, Color(0.8, 0.82, 0.8), 1))
		slot.add_theme_stylebox_override("disabled", _slot_style(Color(0.97, 0.97, 0.97), Color(0.86, 0.87, 0.86), 1))
		slot.pressed.connect(_on_slot_pressed.bind(i))
		_grid.add_child(slot)
		_slots.append(slot)

	# Detail card for the selected item
	_empty_label = Label.new()
	_empty_label.text = "یک آیتم را از بک‌پک انتخاب کن"
	_empty_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_empty_label.add_theme_font_size_override("font_size", 30)
	_empty_label.add_theme_color_override("font_color", INK_SOFT)
	column.add_child(_empty_label)

	_detail = PanelContainer.new()
	_detail.add_theme_stylebox_override("panel", ThemeScript.make_style(Color(0.93, 0.95, 0.93), Color.TRANSPARENT, 0, 28))
	column.add_child(_detail)
	var detail_row := HBoxContainer.new()
	detail_row.add_theme_constant_override("separation", 22)
	_detail.add_child(detail_row)

	_icon = TextureRect.new()
	_icon.custom_minimum_size = Vector2(150, 150)
	_icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	detail_row.add_child(_icon)

	var text_box := VBoxContainer.new()
	text_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	text_box.add_theme_constant_override("separation", 8)
	detail_row.add_child(text_box)
	_name_label = Label.new()
	_name_label.add_theme_font_size_override("font_size", 34)
	_name_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	text_box.add_child(_name_label)
	_desc_label = Label.new()
	_desc_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_desc_label.add_theme_font_size_override("font_size", 25)
	_desc_label.add_theme_color_override("font_color", INK_SOFT)
	text_box.add_child(_desc_label)
	_heal_chip = Label.new()
	_heal_chip.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_heal_chip.add_theme_font_size_override("font_size", 26)
	_heal_chip.add_theme_color_override("font_color", Color.WHITE)
	_heal_chip.add_theme_stylebox_override("normal", ThemeScript.make_style(Color(0.3, 0.62, 0.2), Color.TRANSPARENT, 0, 20))
	_heal_chip.custom_minimum_size = Vector2(150, 44)
	text_box.add_child(_heal_chip)

	_use_button = ThemeScript.make_button("استفاده", "primary")
	_use_button.pressed.connect(_on_use_pressed)
	column.add_child(_use_button)

	Store.changed.connect(refresh)
	_update_detail()


func open() -> void:
	visible = true
	_selected = -1
	refresh()


func refresh() -> void:
	var items := Store.inventory
	_count_pill.text = "%d/%d" % [items.size(), Store.MAX_SLOTS]
	for i in range(_slots.size()):
		var slot := _slots[i]
		if i < items.size():
			slot.icon = ItemDbScript.icon(items[i])
			slot.disabled = false
		else:
			slot.icon = null
			slot.disabled = true
	if _selected >= items.size():
		_selected = -1
	_update_detail()


func _on_slot_pressed(index: int) -> void:
	if index < Store.inventory.size():
		_selected = index
		_update_detail()


func _on_use_pressed() -> void:
	if _selected >= 0:
		item_used.emit(_selected)
		_selected = -1


func _update_detail() -> void:
	var has_selection := _selected >= 0 and _selected < Store.inventory.size()
	_detail.visible = has_selection
	_empty_label.visible = not has_selection
	_use_button.disabled = not has_selection
	for i in range(_slots.size()):
		_slots[i].modulate = Color(1, 1, 1) if i != _selected else Color(0.85, 1.0, 0.8)
	if not has_selection:
		return
	var item_id := Store.inventory[_selected]
	var data := ItemDbScript.get_item(item_id)
	_icon.texture = ItemDbScript.icon(item_id)
	_name_label.text = data["name"]
	_desc_label.text = data["desc"]
	_heal_chip.text = "+%d جان" % data["heal"]


func _card_style() -> StyleBoxFlat:
	var box := ThemeScript.make_style(CARD, Color(0.78, 0.8, 0.78), 2, 40)
	box.shadow_color = Color(0, 0, 0, 0.45)
	box.shadow_size = 18
	box.shadow_offset = Vector2(0, 8)
	box.content_margin_left = 30
	box.content_margin_right = 30
	box.content_margin_top = 28
	box.content_margin_bottom = 28
	return box


func _slot_style(bg: Color, border: Color, width: int) -> StyleBoxFlat:
	var box := ThemeScript.make_style(bg, border, width, 0)
	box.content_margin_left = 8
	box.content_margin_right = 8
	box.content_margin_top = 8
	box.content_margin_bottom = 8
	return box
