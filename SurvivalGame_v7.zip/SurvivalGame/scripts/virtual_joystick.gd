extends Control

const RADIUS := 90.0

var value := Vector2.ZERO
var _finger := -1
var _active := false


func _ready() -> void:
	custom_minimum_size = Vector2(240, 240)
	size = custom_minimum_size
	mouse_filter = Control.MOUSE_FILTER_STOP


func _gui_input(event: InputEvent) -> void:
	var touch := event as InputEventScreenTouch
	var drag := event as InputEventScreenDrag
	var click := event as InputEventMouseButton
	var motion := event as InputEventMouseMotion
	if touch != null:
		if touch.pressed and _finger == -1:
			_finger = touch.index
			_update(touch.position)
		elif not touch.pressed and touch.index == _finger:
			_reset()
		accept_event()
	elif drag != null and drag.index == _finger:
		_update(drag.position)
		accept_event()
	elif click != null and click.button_index == MOUSE_BUTTON_LEFT:
		if click.pressed:
			_active = true
			_update(click.position)
		else:
			_reset()
		accept_event()
	elif motion != null and _active:
		_update(motion.position)
		accept_event()


func _update(pos: Vector2) -> void:
	var offset := pos - size / 2.0
	if offset.length() > RADIUS:
		offset = offset.normalized() * RADIUS
	value = offset / RADIUS
	queue_redraw()


func _reset() -> void:
	_finger = -1
	_active = false
	value = Vector2.ZERO
	queue_redraw()


func _draw() -> void:
	var center := size / 2.0
	draw_circle(center, RADIUS + 12.0, Color(1, 1, 1, 0.1))
	draw_arc(center, RADIUS + 12.0, 0.0, TAU, 64, Color(1, 1, 1, 0.22), 3.0)
	draw_circle(center + value * RADIUS, 44.0, Color(0.5, 0.9, 0.3, 0.5))
