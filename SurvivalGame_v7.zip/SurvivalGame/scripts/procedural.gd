extends RefCounted

# Builds visuals in code. If a real model exists in assets/env, it is used instead,
# which is how you upgrade trees and pumpkins to high-detail models later.

static var _ground_mat: StandardMaterial3D
static var _bark_mat: StandardMaterial3D
static var _leaf_mat: StandardMaterial3D
static var _grass_mats: Array = []
static var _smoke_tex: Texture2D
static var _pumpkin_mat: StandardMaterial3D
static var _face_mat: StandardMaterial3D


static func override_scene(path: String) -> Node3D:
	if not ResourceLoader.exists(path):
		return null
	var scene := load(path) as PackedScene
	if scene == null:
		return null
	return scene.instantiate() as Node3D


static func _noise_tex(c1: Color, c2: Color, freq: float, size: int = 512) -> NoiseTexture2D:
	var noise := FastNoiseLite.new()
	noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	noise.frequency = freq
	noise.fractal_octaves = 5
	var grad := Gradient.new()
	grad.set_color(0, c1)
	grad.set_color(1, c2)
	var tex := NoiseTexture2D.new()
	tex.width = size
	tex.height = size
	tex.seamless = true
	tex.noise = noise
	tex.color_ramp = grad
	return tex


static func ground_material() -> StandardMaterial3D:
	if _ground_mat == null:
		_ground_mat = StandardMaterial3D.new()
		_ground_mat.albedo_texture = load("res://assets/textures/ground_albedo.jpg")
		_ground_mat.normal_enabled = true
		_ground_mat.normal_texture = load("res://assets/textures/ground_normal.jpg")
		_ground_mat.roughness_texture = load("res://assets/textures/ground_rough.jpg")
		_ground_mat.roughness = 0.6
		_ground_mat.metallic_specular = 0.6
		_ground_mat.uv1_triplanar = true
		_ground_mat.uv1_world_triplanar = true
		_ground_mat.vertex_color_use_as_albedo = true
		_ground_mat.uv1_scale = Vector3(0.12, 0.12, 0.12)
		_ground_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
		_ground_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	return _ground_mat


static func bark_material() -> StandardMaterial3D:
	if _bark_mat == null:
		_bark_mat = StandardMaterial3D.new()
		_bark_mat.albedo_texture = _noise_tex(Color(0.16, 0.1, 0.06), Color(0.36, 0.26, 0.17), 0.05, 256)
		_bark_mat.uv1_scale = Vector3(2, 6, 1)
		_bark_mat.roughness = 0.9
	return _bark_mat


static func leaf_material() -> StandardMaterial3D:
	if _leaf_mat == null:
		_leaf_mat = StandardMaterial3D.new()
		_leaf_mat.albedo_texture = _noise_tex(Color(0.1, 0.27, 0.07), Color(0.3, 0.5, 0.14), 0.04, 256)
		_leaf_mat.roughness = 0.85
	return _leaf_mat


static func make_tree(rng: RandomNumberGenerator) -> Node3D:
	var custom := override_scene("res://assets/env/tree.glb")
	if custom != null:
		return custom
	var root := Node3D.new()
	var trunk := MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = 0.22
	cyl.bottom_radius = 0.42
	cyl.height = 5.0
	cyl.radial_segments = 12
	cyl.material = bark_material()
	trunk.mesh = cyl
	trunk.position.y = 2.5
	root.add_child(trunk)
	for i in range(8):
		var clump := MeshInstance3D.new()
		var sphere := SphereMesh.new()
		sphere.radius = rng.randf_range(1.1, 1.7)
		sphere.height = sphere.radius * 1.8
		sphere.radial_segments = 16
		sphere.rings = 8
		sphere.material = leaf_material()
		clump.mesh = sphere
		clump.position = Vector3(rng.randf_range(-1.1, 1.1), rng.randf_range(4.0, 6.0), rng.randf_range(-1.1, 1.1))
		root.add_child(clump)
	return root


const GRASS_VARIANTS := 4


static func grass_variant_count() -> int:
	return GRASS_VARIANTS


# Each variant is a different hand-drawn clump (rounded blade tips, varied heights and colours),
# so the meadow does not look like one copied sprite.
static func grass_material(variant: int) -> StandardMaterial3D:
	var idx := posmod(variant, GRASS_VARIANTS)
	while _grass_mats.size() < GRASS_VARIANTS:
		_grass_mats.append(null)
	if _grass_mats[idx] == null:
		var mat := StandardMaterial3D.new()
		mat.albedo_texture = load("res://assets/textures/grass_clump_%d.png" % idx) as Texture2D
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
		mat.alpha_scissor_threshold = 0.4
		mat.cull_mode = BaseMaterial3D.CULL_DISABLED
		mat.roughness = 0.9
		_grass_mats[idx] = mat
	return _grass_mats[idx]


static func water_material() -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.1, 0.32, 0.42, 0.82)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.roughness = 0.08
	mat.metallic_specular = 0.9
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	return mat


static func stone_material() -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.5, 0.46, 0.4)
	mat.roughness = 0.93
	mat.metallic_specular = 0.3
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	return mat


static func smoke_texture() -> Texture2D:
	if _smoke_tex == null:
		var grad := Gradient.new()
		grad.colors = PackedColorArray([Color(1, 1, 1, 0.9), Color(1, 1, 1, 0.0)])
		grad.offsets = PackedFloat32Array([0.0, 1.0])
		var tex := GradientTexture2D.new()
		tex.gradient = grad
		tex.fill = GradientTexture2D.FILL_RADIAL
		tex.fill_from = Vector2(0.5, 0.5)
		tex.fill_to = Vector2(1.0, 0.5)
		tex.width = 128
		tex.height = 128
		_smoke_tex = tex
	return _smoke_tex


# Ribbed, slightly squashed sphere (a pumpkin), built with SurfaceTool.
static func pumpkin_mesh() -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var rings := 32
	var segs := 48
	for r in range(rings + 1):
		var v := float(r) / rings
		var phi := v * PI
		for s in range(segs + 1):
			var u := float(s) / segs
			var theta := u * TAU
			var ribs := 1.0 + 0.06 * cos(theta * 8.0)
			var radius := 0.5 * ribs
			var x := radius * sin(phi) * cos(theta)
			var y := radius * cos(phi) * 0.85
			var z := radius * sin(phi) * sin(theta)
			st.set_uv(Vector2(u, v))
			st.add_vertex(Vector3(x, y, z))
	for r in range(rings):
		for s in range(segs):
			var i0 := r * (segs + 1) + s
			var i1 := i0 + 1
			var i2 := i0 + (segs + 1)
			var i3 := i2 + 1
			st.add_index(i0)
			st.add_index(i2)
			st.add_index(i1)
			st.add_index(i1)
			st.add_index(i2)
			st.add_index(i3)
	st.generate_normals()
	return st.commit()


static func pumpkin_material() -> StandardMaterial3D:
	if _pumpkin_mat == null:
		_pumpkin_mat = StandardMaterial3D.new()
		_pumpkin_mat.albedo_color = Color(0.95, 0.42, 0.08)
		_pumpkin_mat.albedo_texture = _noise_tex(Color(0.85, 0.35, 0.06), Color(1.0, 0.5, 0.12), 0.08, 256)
		_pumpkin_mat.roughness = 0.5
		_pumpkin_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	return _pumpkin_mat


static func _in_triangle(p: Vector2, a: Vector2, b: Vector2, c: Vector2) -> bool:
	var d1 := (p - b).cross(a - b)
	var d2 := (p - c).cross(b - c)
	var d3 := (p - a).cross(c - a)
	var has_neg := d1 < 0 or d2 < 0 or d3 < 0
	var has_pos := d1 > 0 or d2 > 0 or d3 > 0
	return not (has_neg and has_pos)


# Glowing jack-o'-lantern face, drawn as a transparent texture.
static func face_material() -> StandardMaterial3D:
	if _face_mat == null:
		var size := 256
		var img := Image.create(size, size, false, Image.FORMAT_RGBA8)
		img.fill(Color(0, 0, 0, 0))
		var green := Color(0.55, 1.0, 0.25, 1.0)
		var eye_l := [Vector2(56, 70), Vector2(112, 70), Vector2(84, 128)]
		var eye_r := [Vector2(144, 70), Vector2(200, 70), Vector2(172, 128)]
		for y in range(size):
			for x in range(size):
				var p := Vector2(x, y)
				var in_eye := _in_triangle(p, eye_l[0], eye_l[1], eye_l[2]) or _in_triangle(p, eye_r[0], eye_r[1], eye_r[2])
				var top: float = 150.0 + 20.0 * absf(fmod(float(x), 32.0) - 16.0) / 16.0
				var in_mouth := x >= 48 and x <= 208 and y >= top and y <= 204
				if in_eye or in_mouth:
					img.set_pixel(x, y, green)
		_face_mat = StandardMaterial3D.new()
		_face_mat.albedo_texture = ImageTexture.create_from_image(img)
		_face_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		_face_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
		_face_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		_face_mat.emission_enabled = true
		_face_mat.emission = Color(0.4, 1.0, 0.2)
		_face_mat.emission_energy_multiplier = 2.5
		_face_mat.emission_texture = _face_mat.albedo_texture
	return _face_mat


static func smoke_particles() -> CPUParticles3D:
	var particles := CPUParticles3D.new()
	particles.amount = 60
	particles.lifetime = 5.0
	particles.preprocess = 5.0
	particles.explosiveness = 0.0
	particles.local_coords = false
	particles.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
	particles.emission_sphere_radius = 0.18
	particles.direction = Vector3(0, 1, 0)
	particles.spread = 12.0
	particles.initial_velocity_min = 0.9
	particles.initial_velocity_max = 1.5
	particles.gravity = Vector3(0, 0.05, 0)
	particles.scale_amount_min = 0.9
	particles.scale_amount_max = 1.8
	particles.angle_min = -30.0
	particles.angle_max = 30.0

	var ramp := Gradient.new()
	ramp.colors = PackedColorArray([
		Color(0.6, 1.0, 0.45, 0.0),
		Color(0.4, 1.0, 0.25, 0.45),
		Color(0.2, 0.75, 0.12, 0.0),
	])
	ramp.offsets = PackedFloat32Array([0.0, 0.3, 1.0])
	particles.color_ramp = ramp

	var quad := QuadMesh.new()
	quad.size = Vector2(1.0, 1.0)
	var mat := StandardMaterial3D.new()
	mat.albedo_texture = smoke_texture()
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	mat.vertex_color_use_as_albedo = true
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	mat.no_depth_test = false
	mat.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_DISABLED
	quad.material = mat
	particles.mesh = quad
	return particles
