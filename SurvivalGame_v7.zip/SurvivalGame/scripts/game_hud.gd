extends CanvasLayer

const JoystickScript = preload("res://scripts/virtual_joystick.gd")
const BackpackScript = preload("res://scripts/backpack_panel.gd")
const LootScript = preload("res://scripts/loot_panel.gd")
const ThemeScript = preload("res://scripts/ui_theme.gd")
const AxeScript = preload("res://scripts/axe_tool.gd")
const MinimapScript = preload("res://scripts/minimap.gd")
const WifiScript = preload("res://scripts/wifi_icon.gd")

signal item_used(index: int)
signal interact_pressed
signal exit_pressed
signal slot_pressed(index: int)
signal attack_pressed
signal map_target_set(xz: Vector2)

var joystick: JoystickScript
var backpack: BackpackScript
var loot: LootScript

var _hp_bar: ProgressBar
var _hp_label: Label
var _coin_label: Label
var _interact_button: Button
var _backpack_count: Label
var _toast: Label
var _toast_tween: Tween
var _poison: ColorRect
var _debug: Label
var _fps: Label
var _fps_timer := 0.0
var _slots: Array[Button] = []
var _wood_label: Label
var _attack_button: Button
var minimap: Control
var _full_map: Control
var _wifi: Control


func _ready() -> void:
	layer = 10
	add_to_group("hud")
	_build_top()
	_build_poison()
	_build_debug()
	_build_fps()
	_build_minimap_and_wifi()
	_build_bottom()
	_build_hotbar()
	_build_panels()
	_force_ltr(self)
	Store.changed.connect(_refresh_counts)
	_refresh_counts()


# Persian locale makes the engine mirror LEFT/RIGHT anchors; the HUD layout is
# designed in LTR, so force it on every control.
func _force_ltr(node: Node) -> void:
	var control := node as Control
	if control != null:
		control.layout_direction = Control.LAYOUT_DIRECTION_LTR
	for child in node.get_children():
		_force_ltr(child)


func _process(delta: float) -> void:
	_fps_timer -= delta
	if _fps_timer > 0.0:
		return
	_fps_timer = 0.25
	var fps := Engine.get_frames_per_second()
	_fps.text = "FPS: %d" % int(fps)
	var color := Color(0.5, 1.0, 0.4)
	if fps < 25.0:
		color = Color(1.0, 0.4, 0.35)
	elif fps < 45.0:
		color = Color(1.0, 0.85, 0.3)
	_fps.add_theme_color_override("font_color", color)


func get_move_vector() -> Vector2:
	if joystick == null:
		return Vector2.ZERO
	var v = joystick.get("value")
	return v if v is Vector2 else Vector2.ZERO


func panel_open() -> bool:
	return backpack.visible or loot.visible or (_full_map != null and _full_map.visible)


func set_hp(hp: float, max_hp: float) -> void:
	_hp_bar.max_value = max_hp
	_hp_bar.value = hp
	_hp_label.text = "%d" % int(ceil(hp))


func set_poison(active: bool, delta: float) -> void:
	# The screen is no longer tinted green near pumpkins; the smoke itself is the warning.
	_poison.modulate.a = 0.0


func set_debug(text: String) -> void:
	_debug.text = text


func show_interact(shown: bool) -> void:
	_interact_button.visible = shown


func show_toast(text: String) -> void:
	_toast.text = text
	_toast.modulate.a = 1.0
	if _toast_tween and _toast_tween.is_valid():
		_toast_tween.kill()
	_toast_tween = create_tween()
	_toast_tween.tween_interval(1.4)
	_toast_tween.tween_property(_toast, "modulate:a", 0.0, 0.6)


func _build_top() -> void:
	var top := VBoxContainer.new()
	top.position = Vector2(30, 30)
	top.add_theme_constant_override("separation", 12)
	add_child(top)

	var hp_row := HBoxContainer.new()
	hp_row.add_theme_constant_override("separation", 12)
	top.add_child(hp_row)
	_hp_bar = ProgressBar.new()
	_hp_bar.custom_minimum_size = Vector2(300, 34)
	_hp_bar.show_percentage = false
	_hp_bar.add_theme_stylebox_override("background", ThemeScript.make_style(Color(0.1, 0.1, 0.1, 0.8), Color.TRANSPARENT, 0, 12))
	_hp_bar.add_theme_stylebox_override("fill", ThemeScript.make_style(Color(0.4, 0.85, 0.3), Color.TRANSPARENT, 0, 12))
	hp_row.add_child(_hp_bar)
	_hp_label = Label.new()
	_hp_label.add_theme_font_size_override("font_size", 28)
	hp_row.add_child(_hp_label)

	var exit_button := ThemeScript.make_small_button("خروج")
	exit_button.custom_minimum_size = Vector2(150, 64)
	exit_button.pressed.connect(func() -> void: exit_pressed.emit())
	top.add_child(exit_button)

	_coin_label = Label.new()
	_coin_label.add_theme_font_size_override("font_size", 32)
	_coin_label.add_theme_color_override("font_color", ThemeScript.COLOR_GOLD)
	_coin_label.position = Vector2(0, 30)
	_coin_label.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	_coin_label.offset_right = -30
	_coin_label.offset_left = -300
	_coin_label.offset_top = 30
	_coin_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	add_child(_coin_label)

	_toast = Label.new()
	_toast.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	_toast.offset_left = -330
	_toast.offset_right = 330
	_toast.offset_top = 170
	_toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_toast.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_toast.add_theme_font_size_override("font_size", 32)
	_toast.add_theme_color_override("font_outline_color", Color.BLACK)
	_toast.add_theme_constant_override("outline_size", 8)
	_toast.modulate.a = 0.0
	add_child(_toast)


func _build_debug() -> void:
	_debug = Label.new()
	_debug.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	_debug.offset_left = 30
	_debug.offset_right = 620
	_debug.offset_top = 250
	_debug.offset_bottom = 282
	_debug.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	_debug.add_theme_font_size_override("font_size", 22)
	_debug.add_theme_color_override("font_color", Color(1, 1, 0.6))
	add_child(_debug)


func _build_fps() -> void:
	_fps = Label.new()
	_fps.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	_fps.offset_left = -170
	_fps.offset_right = -30
	_fps.offset_top = 80
	_fps.offset_bottom = 116
	_fps.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_fps.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fps.add_theme_font_size_override("font_size", 26)
	_fps.add_theme_color_override("font_outline_color", Color.BLACK)
	_fps.add_theme_constant_override("outline_size", 6)
	add_child(_fps)


func _build_poison() -> void:
	_poison = ColorRect.new()
	_poison.color = Color(0.35, 1.0, 0.2)
	_poison.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_poison.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_poison.modulate.a = 0.0
	add_child(_poison)


func _build_bottom() -> void:
	joystick = JoystickScript.new()
	joystick.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	joystick.offset_left = 40
	joystick.offset_top = -330
	joystick.offset_right = 280
	joystick.offset_bottom = -90
	add_child(joystick)

	_interact_button = ThemeScript.make_button("باز کردن", "primary")
	_interact_button.custom_minimum_size = Vector2(300, 96)
	_interact_button.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	_interact_button.offset_left = -150
	_interact_button.offset_right = 150
	_interact_button.offset_top = -420
	_interact_button.offset_bottom = -324
	_interact_button.visible = false
	_interact_button.pressed.connect(func() -> void: interact_pressed.emit())
	add_child(_interact_button)

	var backpack_button := ThemeScript.make_button("بک‌پک", "secondary")
	backpack_button.custom_minimum_size = Vector2(240, 120)
	backpack_button.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	backpack_button.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	backpack_button.offset_left = -270
	backpack_button.offset_right = -30
	backpack_button.offset_top = -250
	backpack_button.offset_bottom = -130
	backpack_button.pressed.connect(func() -> void: backpack.open())
	add_child(backpack_button)

	_backpack_count = Label.new()
	_backpack_count.add_theme_font_size_override("font_size", 26)
	_backpack_count.add_theme_color_override("font_color", ThemeScript.COLOR_ACCENT)
	_backpack_count.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	_backpack_count.offset_left = -270
	_backpack_count.offset_right = -30
	_backpack_count.offset_top = -282
	_backpack_count.offset_bottom = -252
	_backpack_count.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(_backpack_count)


func _build_hotbar() -> void:
	var bar := HBoxContainer.new()
	bar.add_theme_constant_override("separation", 8)
	bar.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	bar.offset_left = -172
	bar.offset_right = 172
	bar.offset_top = -110
	bar.offset_bottom = -30
	add_child(bar)

	for i in range(4):
		var slot := Button.new()
		slot.custom_minimum_size = Vector2(80, 80)
		slot.focus_mode = Control.FOCUS_NONE
		slot.add_theme_stylebox_override("normal", _slot_style(false))
		slot.add_theme_stylebox_override("hover", _slot_style(false))
		slot.add_theme_stylebox_override("pressed", _slot_style(false))
		slot.pressed.connect(_on_slot_button.bind(i))
		bar.add_child(slot)
		_slots.append(slot)

	# Slot 1: axe (live 3D render of the scanned model)
	var axe_rect := TextureRect.new()
	axe_rect.texture = _build_axe_icon()
	axe_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	axe_rect.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	axe_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	axe_rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_slots[0].add_child(axe_rect)

	# Slot 2: wood count
	_wood_label = Label.new()
	_wood_label.add_theme_font_size_override("font_size", 24)
	_wood_label.add_theme_color_override("font_color", ThemeScript.COLOR_GOLD)
	_wood_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_wood_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_wood_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_wood_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_slots[1].add_child(_wood_label)

	_attack_button = ThemeScript.make_button("ضربه", "primary")
	_attack_button.custom_minimum_size = Vector2(160, 96)
	_attack_button.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	_attack_button.offset_left = -190
	_attack_button.offset_right = -30
	_attack_button.offset_top = -420
	_attack_button.offset_bottom = -324
	_attack_button.visible = false
	_attack_button.pressed.connect(func() -> void: attack_pressed.emit())
	add_child(_attack_button)


func _build_axe_icon() -> Texture2D:
	var vp := SubViewport.new()
	vp.size = Vector2i(192, 192)
	vp.transparent_bg = true
	vp.own_world_3d = true
	vp.render_target_update_mode = SubViewport.UPDATE_ONCE
	add_child(vp)

	var env := Environment.new()
	env.background_mode = Environment.BG_CLEAR_COLOR
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.7, 0.7, 0.72)
	env.ambient_light_energy = 0.9
	var world := WorldEnvironment.new()
	world.environment = env
	vp.add_child(world)

	var light := DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-50.0, 30.0, 0.0)
	light.light_energy = 1.6
	vp.add_child(light)

	var model := MeshInstance3D.new()
	model.mesh = AxeScript.build_mesh()
	model.material_override = AxeScript.axe_material()
	model.position = Vector3(0.0, -0.37, 0.0)
	model.rotation_degrees = Vector3(0.0, 0.0, -28.0)
	vp.add_child(model)

	var cam := Camera3D.new()
	cam.fov = 24.0
	cam.position = Vector3(0.0, 0.0, 2.0)
	vp.add_child(cam)
	cam.make_current()
	return vp.get_texture()


func _slot_style(active: bool) -> StyleBoxFlat:
	if active:
		return ThemeScript.make_style(Color(0.12, 0.18, 0.1, 0.92), Color(0.62, 0.95, 0.35, 1.0), 3, 16)
	return ThemeScript.make_style(Color(0.05, 0.06, 0.05, 0.8), Color(0.32, 0.27, 0.18, 1.0), 2, 16)


func _on_slot_button(index: int) -> void:
	slot_pressed.emit(index)


# index = the equipped slot, or -1 for none. The attack button is shown only while the axe is in hand.
func set_equipped_slot(index: int) -> void:
	for i in range(_slots.size()):
		var style := _slot_style(i == index)
		_slots[i].add_theme_stylebox_override("normal", style)
		_slots[i].add_theme_stylebox_override("hover", style)
		_slots[i].add_theme_stylebox_override("pressed", style)
	_attack_button.visible = index == 0


func _build_minimap_and_wifi() -> void:
	minimap = MinimapScript.new()
	minimap.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	minimap.offset_left = -330
	minimap.offset_right = -30
	minimap.offset_top = 130
	minimap.offset_bottom = 430
	minimap.target_set.connect(func(xz: Vector2) -> void: map_target_set.emit(xz))
	add_child(minimap)

	_full_map = MinimapScript.new()
	_full_map.full = true
	_full_map.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_full_map.visible = false
	_full_map.target_set.connect(func(xz: Vector2) -> void: map_target_set.emit(xz))
	add_child(_full_map)

	var close := ThemeScript.make_button("بستن", "secondary")
	close.custom_minimum_size = Vector2(180, 80)
	close.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	close.offset_left = -210
	close.offset_right = -30
	close.offset_top = 30
	close.offset_bottom = 110
	close.pressed.connect(func() -> void: _full_map.visible = false)
	_full_map.add_child(close)

	var open := ThemeScript.make_button("نقشه کامل", "secondary")
	open.custom_minimum_size = Vector2(200, 72)
	open.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	open.offset_left = -330
	open.offset_right = -130
	open.offset_top = 440
	open.offset_bottom = 512
	open.pressed.connect(func() -> void: _full_map.visible = true)
	add_child(open)

	_wifi = WifiScript.new()
	_wifi.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	_wifi.offset_left = -32
	_wifi.offset_right = 32
	_wifi.offset_top = 30
	_wifi.offset_bottom = 74
	add_child(_wifi)


func set_map_texture(tex: Texture2D, world_size: float) -> void:
	minimap.setup(tex, world_size)
	_full_map.setup(tex, world_size)


func update_minimap(xz: Vector2, yaw: float, has_target: bool, target: Vector2) -> void:
	minimap.set_state(xz, yaw, has_target, target)
	_full_map.set_state(xz, yaw, has_target, target)


func _build_panels() -> void:
	backpack = BackpackScript.new()
	add_child(backpack)
	backpack.item_used.connect(func(index: int) -> void: item_used.emit(index))
	backpack.close_requested.connect(func() -> void: backpack.visible = false)

	loot = LootScript.new()
	add_child(loot)
	loot.close_requested.connect(func() -> void: loot.visible = false)


func _refresh_counts() -> void:
	_coin_label.text = "سکه: %d" % Store.coins
	_backpack_count.text = "%d/%d" % [Store.inventory.size(), Store.MAX_SLOTS]
	if _wood_label != null:
		_wood_label.text = "%d\nچوب" % Store.wood
