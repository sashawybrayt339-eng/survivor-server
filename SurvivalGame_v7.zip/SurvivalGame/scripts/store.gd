extends Node

# Autoload "Store": coins, backpack inventory and Myket billing for the coin pack.

signal changed
signal coin_result(ok: bool, message: String)

# Product ID created in the Myket panel (consumable, 1000 coins = 10,000 toman).
const COIN_SKU := "GhJLA1000"
const COINS_PER_PACK := 1000
const MAX_SLOTS := 31

# Paste the Base64 public key from Myket developer panel > your app.
const MYKET_PUBLIC_KEY := "PASTE_YOUR_MYKET_PUBLIC_KEY_HERE"
const SAVE_PATH := "user://save.cfg"

var coins: int = 0
var inventory: Array[String] = []
var wood: int = 0

var _plugin: Object = null
var _buy_requested := false
var _buy_pending := false


func _ready() -> void:
	_load()
	if Engine.has_singleton("MyketInAppBilling"):
		_plugin = Engine.get_singleton("MyketInAppBilling")
		_plugin.connect("connected", Callable(self, "_on_connected"))
		_plugin.connect("purchase_finished", Callable(self, "_on_purchase_finished"))
		_plugin.connect("purchases_query_finished", Callable(self, "_on_purchases"))
		_plugin.connect("billing_error", Callable(self, "_on_billing_error"))
		_plugin.setApplicationKey(MYKET_PUBLIC_KEY)
		connect_billing()


func connect_billing() -> void:
	if _plugin == null:
		return
	if _plugin.isReady():
		_plugin.refreshPurchases()
	else:
		_plugin.startConnection()


func buy_coins() -> void:
	if _plugin == null:
		coin_result.emit(false, "خرید فقط داخل نسخهٔ اندرویدی و با مایکت فعال است.")
		return
	if not _plugin.isReady():
		_buy_pending = true
		coin_result.emit(false, "در حال اتصال به مایکت...")
		_plugin.startConnection()
		return
	_buy_requested = true
	var response = _plugin.purchase(COIN_SKU)
	if response is Dictionary and not response.get("successful", true):
		_buy_requested = false
		coin_result.emit(false, str(response.get("message", "خطا در شروع خرید.")))


func add_coins(amount: int) -> void:
	coins += amount
	_save()
	changed.emit()


func add_item(item_id: String) -> bool:
	if inventory.size() >= MAX_SLOTS:
		return false
	inventory.append(item_id)
	_save()
	changed.emit()
	return true


func add_wood(amount: int) -> void:
	wood += amount
	_save()
	changed.emit()


func remove_at(index: int) -> String:
	if index < 0 or index >= inventory.size():
		return ""
	var item_id := inventory[index]
	inventory.remove_at(index)
	_save()
	changed.emit()
	return item_id


func _on_connected(successful: bool, message: String) -> void:
	if successful:
		_plugin.refreshPurchases()
		if _buy_pending:
			_buy_pending = false
			buy_coins()
	else:
		coin_result.emit(false, message)


func _on_purchase_finished(result: Dictionary) -> void:
	if not _buy_requested:
		return
	_buy_requested = false
	if bool(result.get("successful", false)):
		add_coins(COINS_PER_PACK)
		# Consumable: consume it so the player can buy again.
		_plugin.consume(COIN_SKU)
		coin_result.emit(true, "۱۰۰۰ سکه به حسابت اضافه شد.")
	else:
		coin_result.emit(false, str(result.get("message", "خرید انجام نشد.")))


# Unconsumed coin purchases found on restore are consumed only; coins were already granted.
func _on_purchases(purchases: Array) -> void:
	for purchase in purchases:
		if purchase is Dictionary and str(purchase.get("product_id", "")) == COIN_SKU:
			_plugin.consume(COIN_SKU)


func _on_billing_error(error: Dictionary) -> void:
	if _buy_requested:
		_buy_requested = false
		coin_result.emit(false, str(error.get("message", "خطا در ارتباط با مایکت.")))


func _save() -> void:
	var config := ConfigFile.new()
	config.set_value("save", "coins", coins)
	config.set_value("save", "inventory", inventory)
	config.set_value("save", "wood", wood)
	config.save(SAVE_PATH)


func _load() -> void:
	var config := ConfigFile.new()
	if config.load(SAVE_PATH) != OK:
		return
	coins = int(config.get_value("save", "coins", 0))
	inventory.assign(config.get_value("save", "inventory", []))
	wood = int(config.get_value("save", "wood", 0))
