extends RefCounted

# heal = HP restored when used from the backpack.
const ITEMS := {
	"spiral_lollipop": {
		"name": "آبنبات مارپیچ هالووین",
		"desc": "شیرینی سبز و بنفش که مثل یک دایرهٔ جادویی می‌چرخد. برای شب‌های سرد جنگل.",
		"heal": 5,
	},
	"candy_corn": {
		"name": "ذرت شیرین هالووین",
		"desc": "کلاسیک‌ترین شیرینی پاییزی هالووین؛ نارنجی و زرد، شبیه کلاه کوچک یک جادوگر.",
		"heal": 5,
	},
	"mystery_candy": {
		"name": "شکلات سورپرایزی",
		"desc": "با علامت سؤال روی کاغذش. هیچ‌وقت نمی‌دانی طعم بعدی چیست.",
		"heal": 15,
	},
	"striped_candy": {
		"name": "آبنبات راه‌راه",
		"desc": "کوچک و تُرد با راه‌راه‌های بنفش و سبز؛ برای یک گاز سریع وسط تاریکی.",
		"heal": 5,
	},
	"pumpkin_lollipop": {
		"name": "آبنبات کدو تنبل",
		"desc": "نماد اصلی هالووین با چهرهٔ جک‌او‌لنترن؛ همراه همیشگی شب ارواح.",
		"heal": 10,
	},
	"halloween_chocolate": {
		"name": "شکلات هالووین",
		"desc": "تخته‌ای از شکلات با روکش ترسناک و نوشتهٔ سبز. انرژی خوب برای ادامهٔ شب.",
		"heal": 20,
	},
	"eyeball_candy": {
		"name": "آبنبات چشم",
		"desc": "چشمی سبز که از داخل کاغذ به تو نگاه می‌کند. بخور اگر جرئتش را داری.",
		"heal": 10,
	},
}

static var _icon_cache: Dictionary = {}


static func all_ids() -> Array[String]:
	var ids: Array[String] = []
	for key in ITEMS.keys():
		ids.append(key)
	return ids


static func get_item(item_id: String) -> Dictionary:
	return ITEMS.get(item_id, {})


static func icon(item_id: String) -> Texture2D:
	if _icon_cache.has(item_id):
		return _icon_cache[item_id]
	var path := "res://assets/items/%s.png" % item_id
	var tex: Texture2D = null
	if ResourceLoader.exists(path):
		tex = load(path) as Texture2D
	_icon_cache[item_id] = tex
	return tex
