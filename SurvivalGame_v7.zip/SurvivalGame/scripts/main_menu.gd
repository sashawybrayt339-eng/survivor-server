extends Control

const ThemeScript = preload("res://scripts/ui_theme.gd")

const GAME_SCENE := "res://scenes/game.tscn"
const MENU_BG := "res://assets/ui/menu_bg.jpg"

# Online servers. The address stays empty until a server is actually running.
const SERVERS := [
	{"name": "Iran#1", "rate": "منابع 1X", "max": 10, "address": ""},
	{"name": "Iran#2", "rate": "منابع 1X", "max": 10, "address": ""},
	{"name": "Iran#3", "rate": "منابع 1X", "max": 10, "address": ""},
]

var _servers_page: Control
var _notice: Label


func _ready() -> void:
	theme = ThemeScript.build_theme()
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_build_background()
	_build_play_button()
	_build_servers_page()


func _build_background() -> void:
	var bg := TextureRect.new()
	if ResourceLoader.exists(MENU_BG):
		bg.texture = load(MENU_BG) as Texture2D
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)


func _build_play_button() -> void:
	var play := Button.new()
	play.text = "PLAY"
	play.custom_minimum_size = Vector2(360, 110)
	play.focus_mode = Control.FOCUS_NONE
	play.add_theme_font_size_override("font_size", 56)
	play.add_theme_color_override("font_color", Color(0.08, 0.06, 0.0))
	play.add_theme_color_override("font_hover_color", Color(0.08, 0.06, 0.0))
	play.add_theme_color_override("font_pressed_color", Color(0.08, 0.06, 0.0))
	var normal := ThemeScript.make_style(Color(1.0, 0.84, 0.0), Color(0.6, 0.45, 0.0), 4, 24)
	var pressed := ThemeScript.make_style(Color(1.0, 0.92, 0.3), Color(0.6, 0.45, 0.0), 4, 24)
	play.add_theme_stylebox_override("normal", normal)
	play.add_theme_stylebox_override("hover", pressed)
	play.add_theme_stylebox_override("pressed", pressed)
	play.add_theme_stylebox_override("focus", normal)
	play.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	play.offset_left = -180
	play.offset_right = 180
	play.offset_top = -260
	play.offset_bottom = -150
	play.pressed.connect(_on_play_pressed)
	add_child(play)


func _on_play_pressed() -> void:
	_servers_page.visible = true


func _build_servers_page() -> void:
	_servers_page = Control.new()
	_servers_page.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_servers_page.visible = false
	add_child(_servers_page)

	var black := ColorRect.new()
	black.color = Color(0, 0, 0, 1)
	black.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_servers_page.add_child(black)

	var column := VBoxContainer.new()
	column.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	column.offset_left = 60
	column.offset_right = -60
	column.offset_top = 160
	column.offset_bottom = -120
	column.add_theme_constant_override("separation", 22)
	_servers_page.add_child(column)

	for i in range(SERVERS.size()):
		var info: Dictionary = SERVERS[i]
		var row := ThemeScript.make_button("%s\n%s   |   0 / %d نفر" % [info["name"], info["rate"], info["max"]], "secondary")
		row.custom_minimum_size = Vector2(0, 140)
		row.pressed.connect(_on_server_pressed.bind(i))
		column.add_child(row)

	_notice = Label.new()
	_notice.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_notice.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_notice.add_theme_font_size_override("font_size", 28)
	_notice.add_theme_color_override("font_color", ThemeScript.COLOR_GOLD)
	column.add_child(_notice)

	var solo := ThemeScript.make_button("بازی تنها (آفلاین)", "primary")
	solo.pressed.connect(_start_offline)
	column.add_child(solo)

	var back := ThemeScript.make_button("بازگشت", "secondary")
	back.pressed.connect(func() -> void: _servers_page.visible = false)
	column.add_child(back)


func _on_server_pressed(index: int) -> void:
	var info: Dictionary = SERVERS[index]
	if str(info["address"]) == "":
		_notice.text = "%s هنوز روشن نیست. برای بازی، «بازی تنها» را بزن." % info["name"]
		return
	_notice.text = "اتصال به این سرور هنوز پیاده‌سازی نشده است."


func _start_offline() -> void:
	# BugGuard checks that every script compiles; a broken script would
	# otherwise give a blank grey screen instead of the game.
	var guard := get_node_or_null("/root/BugGuard")
	if guard != null:
		var bad: PackedStringArray = guard.call("preflight")
		if not bad.is_empty():
			guard.call("show_report", "این فایل‌ها لود نشدند:\n" + ", ".join(bad))
			return
	var err := get_tree().change_scene_to_file(GAME_SCENE)
	if err != OK and guard != null:
		guard.call("show_report", "لود صحنهٔ بازی ناموفق بود (کد خطا %d)" % err)
