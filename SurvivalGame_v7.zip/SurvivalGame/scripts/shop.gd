extends Control

const ThemeScript = preload("res://scripts/ui_theme.gd")

const MENU_SCENE := "res://scenes/main_menu.tscn"

var _balance_label: Label
var _message: Label
var _buy_button: Button


func _ready() -> void:
	theme = ThemeScript.build_theme()
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var bg := TextureRect.new()
	bg.texture = ThemeScript.background_texture()
	bg.stretch_mode = TextureRect.STRETCH_SCALE
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)

	var column := VBoxContainer.new()
	column.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	column.offset_left = 40
	column.offset_right = -40
	column.offset_top = 60
	column.offset_bottom = -60
	column.add_theme_constant_override("separation", 32)
	add_child(column)

	# Header
	var header := HBoxContainer.new()
	column.add_child(header)
	var back := ThemeScript.make_small_button("بازگشت")
	back.custom_minimum_size = Vector2(190, 72)
	back.pressed.connect(func() -> void: get_tree().change_scene_to_file(MENU_SCENE))
	header.add_child(back)
	var title := Label.new()
	title.text = "فروشگاه"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 46)
	header.add_child(title)
	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(190, 72)
	header.add_child(spacer)

	# Coin pack card
	var card := PanelContainer.new()
	card.add_theme_stylebox_override("panel", ThemeScript.make_style(ThemeScript.COLOR_PANEL, ThemeScript.COLOR_BORDER, 2, 30))
	card.size_flags_vertical = Control.SIZE_EXPAND_FILL
	column.add_child(card)

	var card_box := VBoxContainer.new()
	card_box.alignment = BoxContainer.ALIGNMENT_CENTER
	card_box.add_theme_constant_override("separation", 22)
	card.add_child(card_box)

	var coin := TextureRect.new()
	coin.texture = load("res://assets/ui/coin.png")
	coin.custom_minimum_size = Vector2(260, 260)
	coin.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	coin.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	coin.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	card_box.add_child(coin)

	var amount := Label.new()
	amount.text = "۱۰۰۰ سکه"
	amount.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	amount.add_theme_font_size_override("font_size", 56)
	amount.add_theme_color_override("font_color", ThemeScript.COLOR_GOLD)
	card_box.add_child(amount)

	var price := Label.new()
	price.text = "۱۰,۰۰۰ تومان"
	price.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	price.add_theme_font_size_override("font_size", 40)
	card_box.add_child(price)

	_balance_label = Label.new()
	_balance_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_balance_label.add_theme_font_size_override("font_size", 30)
	_balance_label.add_theme_color_override("font_color", ThemeScript.COLOR_MUTED)
	card_box.add_child(_balance_label)

	_buy_button = ThemeScript.make_button("خرید سکه", "primary")
	_buy_button.pressed.connect(_on_buy_pressed)
	card_box.add_child(_buy_button)

	_message = Label.new()
	_message.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_message.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_message.add_theme_font_size_override("font_size", 28)
	_message.custom_minimum_size = Vector2(0, 80)
	column.add_child(_message)

	Store.changed.connect(_refresh)
	Store.coin_result.connect(_on_coin_result)
	_refresh()
	Store.connect_billing()


func _refresh() -> void:
	_balance_label.text = "موجودی فعلی: %d سکه" % Store.coins


func _on_buy_pressed() -> void:
	_message.text = "در حال پردازش خرید..."
	Store.buy_coins()


func _on_coin_result(ok: bool, text: String) -> void:
	_message.text = text
	_message.add_theme_color_override("font_color", ThemeScript.COLOR_ACCENT if ok else Color(1, 0.5, 0.4))
	_refresh()
