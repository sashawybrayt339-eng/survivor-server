extends Node3D

const ProceduralScript = preload("res://scripts/procedural.gd")
const ItemDbScript = preload("res://scripts/item_db.gd")

# Pumpkins release toxic green smoke. Standing inside it drains HP.
const POISON_RADIUS := 2.4

var poison_radius := POISON_RADIUS
var loot: Array[String] = []


func _ready() -> void:
	# Each pumpkin holds exactly two whole candies, picked at random.
	var ids := ItemDbScript.all_ids()
	ids.shuffle()
	loot.clear()
	loot.append(ids[0])
	loot.append(ids[1])
	var custom := ProceduralScript.override_scene("res://assets/env/pumpkin.glb")
	if custom != null:
		add_child(custom)
	else:
		var body := MeshInstance3D.new()
		body.mesh = ProceduralScript.pumpkin_mesh()
		body.material_override = ProceduralScript.pumpkin_material()
		body.position.y = 0.45
		add_child(body)

		var stem := MeshInstance3D.new()
		var cyl := CylinderMesh.new()
		cyl.top_radius = 0.04
		cyl.bottom_radius = 0.07
		cyl.height = 0.22
		cyl.material = ProceduralScript.bark_material()
		stem.mesh = cyl
		stem.position = Vector3(0, 0.95, 0)
		add_child(stem)

		var face := MeshInstance3D.new()
		var plane := PlaneMesh.new()
		plane.size = Vector2(0.5, 0.5)
		plane.material = ProceduralScript.face_material()
		face.mesh = plane
		face.rotation_degrees = Vector3(90, 0, 0)
		face.position = Vector3(0, 0.45, 0.5)
		add_child(face)

	var smoke := ProceduralScript.smoke_particles()
	smoke.position = Vector3(0, 0.6, 0)
	add_child(smoke)


func has_loot() -> bool:
	return not loot.is_empty()
