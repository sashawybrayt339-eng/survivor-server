extends Node3D

const ProceduralScript = preload("res://scripts/procedural.gd")
const PumpkinScript = preload("res://scripts/pumpkin.gd")
const PlayerScript = preload("res://scripts/player.gd")
const HudScript = preload("res://scripts/game_hud.gd")
const ThemeScript = preload("res://scripts/ui_theme.gd")
const ItemDbScript = preload("res://scripts/item_db.gd")
const TerrainScript = preload("res://scripts/terrain.gd")
const AxeScript = preload("res://scripts/axe_tool.gd")

# Sun direction (elevation ~34 degrees at noon).
const MOON_DIRECTION := Vector3(-0.35, 0.45, 0.82)

# Full day/night loop in seconds: day 300, sunset 30, night 120, red moon night 120, green fog 180, dawn 30.
const CYCLE_SECONDS := 780.0

# Sky shader: samples the same HDR panorama, then tints it and adds stars and a moon.
const SKY_SHADER := """
shader_type sky;

uniform vec3 tint = vec3(1.0);
uniform float brightness = 1.0;
uniform float star_amount = 0.0;
uniform float moon_amount = 0.0;
uniform vec3 moon_dir = vec3(-0.35, 0.45, 0.82);
uniform vec3 moon_color = vec3(1.0, 0.5, 0.42);
uniform vec3 sun_dir = vec3(0.27, 0.56, -0.78);
uniform vec3 sun_color = vec3(1.0, 0.95, 0.85);
uniform float sun_amount = 0.0;

void sky() {
	vec3 d = normalize(EYEDIR);
	// Plain sky: one colour, a little brighter near the horizon.
	vec3 col = tint * brightness * mix(1.25, 0.75, clamp(d.y, 0.0, 1.0));

	vec3 cell = floor(d * 240.0);
	float h = fract(sin(dot(cell, vec3(127.1, 311.7, 74.7))) * 43758.5453);
	float star = step(0.9975, h) * (0.5 + 0.5 * fract(h * 37.0));
	star *= smoothstep(0.05, 0.25, d.y) * star_amount;
	col += vec3(star);

	float md = acos(clamp(dot(d, normalize(moon_dir)), -1.0, 1.0));
	float disc = 1.0 - smoothstep(0.045, 0.052, md);
	float glow = exp(-md * 9.0) * 0.45;
	col += moon_color * (disc * 2.2 + glow) * moon_amount;

	float sd = max(dot(d, normalize(sun_dir)), 0.0);
	col += sun_color * sun_amount * (pow(sd, 5.0) * 0.5 + pow(sd, 80.0) * 1.2 + pow(sd, 1500.0) * 8.0);

	COLOR = col;
}
"""
const SUN_DIRECTION := Vector3(0.2703, 0.5619, -0.7818)

const MENU_SCENE := "res://scenes/main_menu.tscn"
const LOADING_MIN_SECONDS := 10.0
const TREE_COUNT := 240
const TREE_RANGE := 420.0
const GRASS_PER_VARIANT := 900
const AXE_REACH := 3.0
const AXE_COOLDOWN := 0.45
const WOOD_PER_HIT := 10
const TREE_CHUNK := 10
const PUMPKIN_START := 8
const MAX_HP := 100.0
const POISON_DPS := 1.5
const PICKUP_RANGE := 2.8
const TREE_MIN_SPAWN_DISTANCE := 7.0
const PUMPKIN_MAX := 10
const PUMPKIN_SPAWN_INTERVAL := 4.0
const TREE_VISIBLE_DISTANCE := 55.0
const LOADING_MAX_SECONDS := 25.0
const QUALITY_SHADOW_DISTANCE := [45.0, 30.0, 20.0]
const QUALITY_TREE_DISTANCE := [55.0, 40.0, 28.0]
const LOADING_TIPS := [
	"کدو تنبل‌ها دود سمی دارند؛ هرچه می‌توانی از دودشان دور بمان.",
	"با جوی‌استیک حرکت کن و با کشیدن انگشت روی سمت راست صفحه نگاه کن.",
	"داخل کدو تنبل یک بک‌پک کوچک هست؛ روی هر آیتم بزن تا برداشته شود.",
	"تبر را از نوار پایین صفحه بردار و روی درخت‌ها «ضربه» بزن تا چوب بگیری.",
	"از بک‌پک برای استفاده از شیرینی‌ها و بازگرداندن جان استفاده کن.",
	"سکه‌ها را در فروشگاه می‌توانی تهیه کنی.",
]

var player: Node3D
var hud: CanvasLayer
var hp := MAX_HP

var _rng := RandomNumberGenerator.new()
var _tree_positions: Array[Vector2] = []
var _pumpkins: Array = []
var _spawn_timer := 0.0
var _nearby: Node3D = null
var _sun: DirectionalLight3D
var _tree_roots: Array[Node3D] = []
var _debug_timer := 0.0

# axe / chopping
var _axe: Node3D = null
var _axe_equipped := false
var _mark: Label3D
var _tree_spots: Dictionary = {}
var _attack_cd := 0.0
var _clean_time := 0.0
var _map_tex: Texture2D = null
var _waypoint := Vector2.ZERO
var _has_waypoint := false
var _wp_mark: Label3D = null

# loading
var _steps: Array[Callable] = []
var _step_index := 0
var _loading_time := 0.0
var _loaded := false
var _tip_timer := 0.0
var _tip_index := 0

# day / night cycle
var _cycle_time := 0.0
var _keys: Array = []
var _env: Environment = null
var _sky_mat: ShaderMaterial = null
var _sky_is_custom := false
var _sun_dir := Vector3(0.27, 0.56, -0.78)
var _sun_amount := 1.0
var _glare: TextureRect = null
var _overlay: CanvasLayer
var _progress: ProgressBar
var _percent: Label
var _tip_label: Label


func _ready() -> void:
	_rng.randomize()
	get_viewport().msaa_3d = Viewport.MSAA_2X
	get_viewport().screen_space_aa = Viewport.SCREEN_SPACE_AA_FXAA
	_build_keys()
	_build_glare()
	_build_loading_overlay()
	_build_marker()
	_steps.append(Callable(self, "_step_environment"))
	_steps.append(Callable(self, "_step_ground"))
	_steps.append(Callable(self, "_step_grass"))
	_steps.append(Callable(self, "_step_player"))
	for i in range(TREE_COUNT / TREE_CHUNK):
		_steps.append(Callable(self, "_step_trees"))
	for i in range(PUMPKIN_START):
		_steps.append(Callable(self, "_step_pumpkin"))
	for i in range(10):
		_steps.append(Callable(self, "_step_warmup"))


func _process(delta: float) -> void:
	if not _loaded:
		_process_loading(delta)
		return

	if not is_instance_valid(player) or not is_instance_valid(hud):
		_ensure_core()
		return

	var panel_open: bool = hud.panel_open()
	player.control_enabled = not panel_open
	player.move_input = hud.get_move_vector()

	# Poison: only inside a pumpkin's smoke column. HP slowly comes back when clear.
	var in_poison := false
	var pp: Vector3 = player.global_position
	for pumpkin in _pumpkins:
		if not is_instance_valid(pumpkin):
			continue
		var pc: Vector3 = pumpkin.global_position
		var flat := Vector2(pc.x - pp.x, pc.z - pp.z).length()
		if flat < pumpkin.poison_radius and pp.y < pc.y + 2.2:
			in_poison = true
			break
	if in_poison:
		hp -= POISON_DPS * delta
		_clean_time = 0.0
	else:
		_clean_time += delta
		if _clean_time > 3.0:
			hp = min(MAX_HP, hp + 4.0 * delta)
	hud.set_poison(in_poison, delta)

	if hp <= 0.0:
		hp = MAX_HP
		player.global_position = TerrainScript.spawn_point()
		hud.show_toast("جانت تمام شد؛ دوباره از نقطهٔ شروع شروع کردی.")
	hud.set_hp(hp, MAX_HP)
	_attack_cd = maxf(0.0, _attack_cd - delta)
	_advance_time(delta)
	_update_aim(panel_open)
	_update_map_and_waypoint()
	_debug_timer -= delta
	if _debug_timer <= 0.0:
		_debug_timer = 0.25
		hud.set_debug("درخت: %d | کدو: %d | موقعیت: %.0f, %.1f, %.0f" % [
			_tree_positions.size(), _pumpkins.size(),
			player.global_position.x, player.global_position.y, player.global_position.z])

	# Nearest pumpkin that still has loot
	_nearby = null
	var best := PICKUP_RANGE
	for pumpkin in _pumpkins:
		if not is_instance_valid(pumpkin) or not pumpkin.has_loot():
			continue
		var d: float = pumpkin.global_position.distance_to(player.global_position)
		if d < best:
			best = d
			_nearby = pumpkin
	hud.show_interact(_nearby != null and not panel_open)

	_spawn_timer -= delta
	if _spawn_timer <= 0.0:
		_spawn_timer = PUMPKIN_SPAWN_INTERVAL
		if _pumpkins.size() < PUMPKIN_MAX and _is_night_time(_cycle_time):
			_spawn_pumpkin()


func _unhandled_input(event: InputEvent) -> void:
	if not _loaded or hud.panel_open():
		return
	var viewport_width := get_viewport().get_visible_rect().size.x
	var drag := event as InputEventScreenDrag
	var motion := event as InputEventMouseMotion
	if DisplayServer.is_touchscreen_available():
		if drag != null and drag.position.x > viewport_width * 0.4:
			player.look(drag.relative)
	elif motion != null and (motion.button_mask & MOUSE_BUTTON_MASK_LEFT) != 0:
		player.look(motion.relative)


func _on_interact_pressed() -> void:
	if _nearby != null:
		hud.loot.open(_nearby.loot)


func _on_item_used(index: int) -> void:
	var item_id := Store.remove_at(index)
	if item_id == "":
		return
	var data := ItemDbScript.get_item(item_id)
	hp = min(MAX_HP, hp + float(data["heal"]))
	hud.show_toast("%s خوردی. +%d جان" % [data["name"], data["heal"]])


# ---------- loading ----------

func _process_loading(delta: float) -> void:
	_loading_time += delta
	if _step_index < _steps.size():
		_steps[_step_index].call()
		_step_index += 1

	var steps_frac: float = float(_step_index) / float(_steps.size())
	var time_frac: float = clamp(_loading_time / LOADING_MIN_SECONDS, 0.0, 1.0)
	var progress: float = min(steps_frac, time_frac)
	_progress.value = progress * 100.0
	_percent.text = "%d٪" % int(progress * 100.0)

	_tip_timer -= delta
	if _tip_timer <= 0.0:
		_tip_timer = 2.5
		_tip_index = (_tip_index + 1) % LOADING_TIPS.size()
		_tip_label.text = LOADING_TIPS[_tip_index]

	if _step_index >= _steps.size() and _loading_time >= LOADING_MIN_SECONDS:
		_finish_loading()
	elif _loading_time >= LOADING_MAX_SECONDS:
		# Something stalled; never leave the player stuck on the loading screen.
		push_warning("Loading watchdog fired; finishing with %d/%d steps." % [_step_index, _steps.size()])
		_finish_loading()


func _ensure_core() -> void:
	# Self-heal: rebuild the player/HUD if a loading step failed.
	if is_instance_valid(player):
		player.queue_free()
	if is_instance_valid(hud):
		hud.queue_free()
	player = null
	hud = null
	_step_player()
	hud.visible = _loaded
	player.control_enabled = _loaded


func _finish_loading() -> void:
	if not is_instance_valid(player) or not is_instance_valid(hud):
		_ensure_core()
	_loaded = true
	_overlay.visible = false
	hud.visible = true
	player.control_enabled = true
	hud.show_toast("به جنگل خوش آمدی.")


func _build_loading_overlay() -> void:
	_overlay = CanvasLayer.new()
	_overlay.layer = 100
	add_child(_overlay)

	var bg := ColorRect.new()
	bg.color = Color(0.04, 0.05, 0.04, 1.0)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_overlay.add_child(bg)
	var splash := TextureRect.new()
	if ResourceLoader.exists("res://assets/ui/splash.jpg"):
		splash.texture = load("res://assets/ui/splash.jpg") as Texture2D
	splash.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	splash.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	splash.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_overlay.add_child(splash)
	var shade := ColorRect.new()
	shade.color = Color(0.02, 0.03, 0.02, 0.55)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_overlay.add_child(shade)

	var column := VBoxContainer.new()
	column.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	column.offset_left = -300
	column.offset_right = 300
	column.offset_top = -200
	column.offset_bottom = 200
	column.add_theme_constant_override("separation", 26)
	column.layout_direction = Control.LAYOUT_DIRECTION_LTR
	_overlay.add_child(column)

	var title := Label.new()
	title.text = "در حال ساخت جنگل..."
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 46)
	title.add_theme_color_override("font_color", Color(0.42, 0.85, 0.28))
	column.add_child(title)

	_progress = ProgressBar.new()
	_progress.custom_minimum_size = Vector2(600, 36)
	_progress.show_percentage = false
	_progress.add_theme_stylebox_override("background", ThemeScript.make_style(Color(0.12, 0.14, 0.12), Color.TRANSPARENT, 0, 14))
	_progress.add_theme_stylebox_override("fill", ThemeScript.make_style(Color(0.42, 0.85, 0.28), Color.TRANSPARENT, 0, 14))
	column.add_child(_progress)

	_percent = Label.new()
	_percent.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_percent.add_theme_font_size_override("font_size", 34)
	column.add_child(_percent)

	_tip_label = Label.new()
	_tip_label.text = LOADING_TIPS[0]
	_tip_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_tip_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_tip_label.add_theme_font_size_override("font_size", 28)
	_tip_label.add_theme_color_override("font_color", ThemeScript.COLOR_MUTED)
	_tip_label.custom_minimum_size = Vector2(600, 90)
	column.add_child(_tip_label)


# ---------- loading steps (each runs in its own frame) ----------

func _step_environment() -> void:
	var sky := Sky.new()
	sky.radiance_size = Sky.RADIANCE_SIZE_128
	var shader := Shader.new()
	shader.code = SKY_SHADER
	_sky_mat = ShaderMaterial.new()
	_sky_mat.shader = shader
	_sky_mat.set_shader_parameter("moon_dir", MOON_DIRECTION)
	_sky_is_custom = true
	sky.sky_material = _sky_mat

	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 1.4
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color(0.45, 0.46, 0.48)
	env.fog_density = 0.003
	env.fog_sky_affect = 0.1
	env.glow_enabled = true
	env.glow_intensity = 0.35
	env.glow_bloom = 0.05
	env.glow_hdr_threshold = 1.8
	var world := WorldEnvironment.new()
	_env = env
	world.environment = env
	add_child(world)

	_sun = DirectionalLight3D.new()
	_sun.light_color = Color(1.0, 0.95, 0.85)
	_sun.light_energy = 1.8
	_sun.shadow_enabled = true
	_sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	_sun.directional_shadow_max_distance = QUALITY_SHADOW_DISTANCE[0]
	add_child(_sun)
	# Light travels away from the sun in the sky, so aim it at -SUN_DIRECTION.
	_sun.look_at_from_position(Vector3.ZERO, -SUN_DIRECTION.normalized(), Vector3.UP)


func _step_ground() -> void:
	var mesh := TerrainScript.build_mesh()
	var ground := MeshInstance3D.new()
	ground.mesh = mesh
	ground.material_override = ProceduralScript.ground_material()
	add_child(ground)

	var body := StaticBody3D.new()
	var collider := CollisionShape3D.new()
	var shape := mesh.create_trimesh_shape()
	shape.backface_collision = true
	collider.shape = shape
	body.add_child(collider)
	add_child(body)
	_map_tex = TerrainScript.build_minimap(256)
	var water := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(4000, 4000)
	water.mesh = plane
	water.material_override = ProceduralScript.water_material()
	water.position = Vector3(0, TerrainScript.SEA_LEVEL, 0)
	add_child(water)


func _step_grass() -> void:
	for variant in range(ProceduralScript.grass_variant_count()):
		var quad := QuadMesh.new()
		quad.size = Vector2(0.9, 0.75)
		quad.material = ProceduralScript.grass_material(variant)
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.mesh = quad
		mm.instance_count = GRASS_PER_VARIANT
		for i in range(GRASS_PER_VARIANT):
			var s := _rng.randf_range(0.7, 1.35)
			var gx := _rng.randf_range(-90, 90)
			var gz := _rng.randf_range(-90, 90)
			var pos := Vector3(gx, TerrainScript.height_at(gx, gz) + 0.375 * s, gz)
			var basis := Basis(Vector3.UP, _rng.randf() * TAU).scaled(Vector3.ONE * s)
			mm.set_instance_transform(i, Transform3D(basis, pos))
		var instance := MultiMeshInstance3D.new()
		instance.multimesh = mm
		instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(instance)


func _step_player() -> void:
	player = PlayerScript.new()
	player.position = TerrainScript.spawn_point()
	player.control_enabled = false
	add_child(player)
	player.make_camera_current()

	_axe = AxeScript.new()
	var cam := player.call("get_camera") as Camera3D
	if cam != null:
		cam.add_child(_axe)
	_axe.call("set_equipped", _axe_equipped)

	hud = HudScript.new()
	hud.visible = false
	add_child(hud)
	hud.item_used.connect(_on_item_used)
	hud.interact_pressed.connect(_on_interact_pressed)
	hud.exit_pressed.connect(func() -> void: get_tree().change_scene_to_file(MENU_SCENE))
	hud.slot_pressed.connect(_on_slot_pressed)
	hud.attack_pressed.connect(_on_attack_pressed)
	hud.map_target_set.connect(_on_map_target)
	hud.set_map_texture(_map_tex, TerrainScript.SIZE)
	hud.set_hp(hp, MAX_HP)
	hud.set_equipped_slot(0 if _axe_equipped else -1)


func _step_trees() -> void:
	for i in range(TREE_CHUNK):
		var pos := Vector2.ZERO
		var found := false
		for attempt in range(20):
			pos = Vector2(_rng.randf_range(-TREE_RANGE, TREE_RANGE), _rng.randf_range(-TREE_RANGE, TREE_RANGE))
			if pos.length() >= TREE_MIN_SPAWN_DISTANCE and _far_from_trees(pos, 3.0) and TerrainScript.height_at(pos.x, pos.y) > 0.6 and TerrainScript.road_weight(pos.x, pos.y) < 0.3:
				found = true
				break
		if not found:
			continue
		_tree_positions.append(pos)
		var tree := ProceduralScript.make_tree(_rng)
		tree.position = Vector3(pos.x, TerrainScript.height_at(pos.x, pos.y), pos.y)
		tree.rotation.y = _rng.randf() * TAU
		var s := _rng.randf_range(0.85, 1.25)
		tree.scale = Vector3.ONE * s
		_limit_visibility(tree)
		_tree_roots.append(tree)
		add_child(tree)

		var body := StaticBody3D.new()
		var shape := CylinderShape3D.new()
		shape.radius = 0.42 * s
		shape.height = 6.0
		var collider := CollisionShape3D.new()
		collider.shape = shape
		collider.position.y = 3.0
		body.add_child(collider)
		body.position = tree.position
		body.add_to_group("chop_target")
		body.set_meta("tree_root", tree)
		add_child(body)


func _step_pumpkin() -> void:
	if _is_night_time(_cycle_time):
		_spawn_pumpkin()


func _step_warmup() -> void:
	# Gives the renderer a few frames to compile shaders and upload textures.
	pass


# ---------- day / night cycle ----------

# Keyframes: [time in cycle, values]. Values are interpolated between neighbouring keys.
func _build_keys() -> void:
	var day := {"elev": 34.0, "tint": Color(0.42, 0.62, 0.92), "bright": 1.0, "stars": 0.0, "moon": 0.0, "fog": Color(0.45, 0.46, 0.48), "density": 0.003, "ambient": 1.4, "sun": 1.8, "scatter": 0.25}
	var dark := {"elev": -18.0, "tint": Color(0.38, 0.45, 0.65), "bright": 0.4, "stars": 1.0, "moon": 0.0, "fog": Color(0.1, 0.13, 0.2), "density": 0.005, "ambient": 0.6, "sun": 0.0, "scatter": 0.0}
	var red := {"elev": -18.0, "tint": Color(1.0, 0.42, 0.36), "bright": 0.6, "stars": 0.6, "moon": 1.0, "fog": Color(0.55, 0.25, 0.24), "density": 0.008, "ambient": 0.7, "sun": 0.0, "scatter": 0.12}
	var green := {"elev": -18.0, "tint": Color(0.45, 0.66, 0.5), "bright": 0.42, "stars": 0.0, "moon": 0.0, "fog": Color(0.22, 0.55, 0.28), "density": 0.03, "ambient": 0.8, "sun": 0.0, "scatter": 0.02}
	_keys = [
		[0.0, day],
		[300.0, day],
		[330.0, dark],
		[450.0, dark],
		[465.0, red],
		[570.0, red],
		[585.0, green],
		[750.0, green],
		[CYCLE_SECONDS, day],
	]


func _sample(t: float) -> Dictionary:
	var a: Array = _keys[0]
	var b: Array = _keys[1]
	for i in range(_keys.size() - 1):
		if t >= float(_keys[i][0]) and t < float(_keys[i + 1][0]):
			a = _keys[i]
			b = _keys[i + 1]
			break
	var span: float = float(b[0]) - float(a[0])
	var f: float = 0.0
	if span > 0.0:
		f = clampf((t - float(a[0])) / span, 0.0, 1.0)
	var da: Dictionary = a[1]
	var db: Dictionary = b[1]
	return {
		"elev": lerpf(float(da["elev"]), float(db["elev"]), f),
		"tint": (da["tint"] as Color).lerp(db["tint"] as Color, f),
		"bright": lerpf(float(da["bright"]), float(db["bright"]), f),
		"stars": lerpf(float(da["stars"]), float(db["stars"]), f),
		"moon": lerpf(float(da["moon"]), float(db["moon"]), f),
		"fog": (da["fog"] as Color).lerp(db["fog"] as Color, f),
		"density": lerpf(float(da["density"]), float(db["density"]), f),
		"ambient": lerpf(float(da["ambient"]), float(db["ambient"]), f),
		"sun": lerpf(float(da["sun"]), float(db["sun"]), f),
		"scatter": lerpf(float(da["scatter"]), float(db["scatter"]), f),
	}


func _advance_time(delta: float) -> void:
	var prev := _cycle_time
	_cycle_time = fmod(_cycle_time + delta, CYCLE_SECONDS)
	_check_events(prev, _cycle_time)
	if _is_night_time(prev) and not _is_night_time(_cycle_time):
		_clear_pumpkins()
	_apply_time(_cycle_time)
	_update_glare()


func _apply_time(t: float) -> void:
	var s := _sample(t)
	var el := deg_to_rad(float(s["elev"]))
	var horiz := Vector3(SUN_DIRECTION.x, 0.0, SUN_DIRECTION.z).normalized()
	var dir := Vector3(horiz.x * cos(el), sin(el), horiz.z * cos(el))
	_sun_dir = dir
	_sun_amount = clampf(float(s["sun"]) / 1.8, 0.0, 1.0)
	# Warm orange when the sun is low, almost white at noon.
	var warmth := 1.0 - smoothstep(0.0, 34.0, float(s["elev"]))
	var sun_col := Color(1.0, 0.95, 0.85).lerp(Color(1.0, 0.55, 0.22), warmth)
	if _sun != null:
		_sun.light_energy = float(s["sun"])
		_sun.light_color = sun_col
		_sun.look_at_from_position(Vector3.ZERO, -dir, Vector3.UP)
	if _sky_is_custom and _sky_mat != null:
		var tc: Color = s["tint"]
		_sky_mat.set_shader_parameter("tint", Vector3(tc.r, tc.g, tc.b))
		_sky_mat.set_shader_parameter("brightness", float(s["bright"]))
		_sky_mat.set_shader_parameter("star_amount", float(s["stars"]))
		_sky_mat.set_shader_parameter("moon_amount", float(s["moon"]))
		_sky_mat.set_shader_parameter("sun_dir", _sun_dir)
		_sky_mat.set_shader_parameter("sun_amount", _sun_amount)
		_sky_mat.set_shader_parameter("sun_color", Vector3(sun_col.r, sun_col.g, sun_col.b))
	if _env != null:
		_env.ambient_light_energy = float(s["ambient"])
		_env.fog_light_color = s["fog"]
		_env.fog_density = float(s["density"])
		_env.fog_sun_scatter = float(s["scatter"]) * (0.4 + 0.6 * _sun_amount + warmth * 0.6)


# Pumpkins only exist at night (dusk to dawn).
func _is_night_time(t: float) -> bool:
	return t >= 330.0 and t < 750.0


func _clear_pumpkins() -> void:
	_nearby = null
	for p in _pumpkins:
		if is_instance_valid(p):
			p.queue_free()
	_pumpkins.clear()


func _check_events(prev: float, now: float) -> void:
	if not _loaded or not is_instance_valid(hud):
		return
	var events := [[0.0, "روز شد."], [330.0, "شب شد."], [570.0, "مه سبز غلیظ شد."]]
	for ev in events:
		if _crossed(prev, now, float(ev[0])):
			hud.show_toast(str(ev[1]))


func _crossed(prev: float, now: float, at: float) -> bool:
	if now >= prev:
		return prev < at and now >= at
	return at > prev or at <= now


# ---------- sun glare ----------

func _build_glare() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 5
	add_child(layer)
	var grad := Gradient.new()
	grad.offsets = PackedFloat32Array([0.0, 0.1, 0.35, 1.0])
	grad.colors = PackedColorArray([
		Color(1, 1, 1, 1.0), Color(1, 1, 1, 0.7), Color(1, 1, 1, 0.12), Color(1, 1, 1, 0.0),
	])
	var tex := GradientTexture2D.new()
	tex.gradient = grad
	tex.fill = GradientTexture2D.FILL_RADIAL
	tex.fill_from = Vector2(0.5, 0.5)
	tex.fill_to = Vector2(1.0, 0.5)
	tex.width = 256
	tex.height = 256
	_glare = TextureRect.new()
	_glare.texture = tex
	_glare.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_glare.stretch_mode = TextureRect.STRETCH_SCALE
	_glare.custom_minimum_size = Vector2(900, 900)
	_glare.size = Vector2(900, 900)
	_glare.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var mat := CanvasItemMaterial.new()
	mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	_glare.material = mat
	_glare.visible = false
	layer.add_child(_glare)


# The glare follows the sun on screen, so it slides across the view as the player turns.
func _update_glare() -> void:
	if _glare == null or not is_instance_valid(player):
		return
	var cam := player.call("get_camera") as Camera3D
	if cam == null:
		return
	var facing := (-cam.global_transform.basis.z).dot(_sun_dir)
	var strength := smoothstep(0.55, 0.98, facing) * _sun_amount
	var sun_pt := cam.global_position + _sun_dir * 500.0
	if strength <= 0.01 or cam.is_position_behind(sun_pt):
		_glare.visible = false
		return
	var vp := get_viewport()
	var screen_pt := cam.unproject_position(sun_pt)
	var canvas_scale := vp.get_visible_rect().size / Vector2(vp.size)
	_glare.visible = true
	_glare.position = screen_pt * canvas_scale - _glare.size * 0.5
	_glare.modulate = Color(1.0, 0.6, 0.26, clampf(strength * 0.55, 0.0, 1.0))


# ---------- map & waypoint ----------

func _on_map_target(xz: Vector2) -> void:
	_waypoint = xz
	_has_waypoint = true
	hud.show_toast("نشانه روی نقشه گذاشته شد.")


func _update_map_and_waypoint() -> void:
	if not is_instance_valid(player) or not is_instance_valid(hud) or _wp_mark == null:
		return
	var pxz := Vector2(player.global_position.x, player.global_position.z)
	if _has_waypoint and pxz.distance_to(_waypoint) < 6.0:
		_has_waypoint = false
		hud.show_toast("به نشانه رسیدی.")
	hud.update_minimap(pxz, player.rotation.y, _has_waypoint, _waypoint)
	if not _has_waypoint:
		_wp_mark.visible = false
		return
	var d := pxz.distance_to(_waypoint)
	_wp_mark.visible = true
	_wp_mark.global_position = Vector3(_waypoint.x, TerrainScript.height_at(_waypoint.x, _waypoint.y) + 3.0, _waypoint.y)
	_wp_mark.text = "◆\n%d م" % int(d)


# ---------- axe / chopping ----------

func _build_marker() -> void:
	_mark = Label3D.new()
	_mark.text = "+"
	_mark.font_size = 160
	_mark.pixel_size = 0.0009
	_mark.modulate = Color(1.0, 0.08, 0.06, 1.0)
	_mark.outline_modulate = Color(0.25, 0.0, 0.0, 1.0)
	_mark.outline_size = 14
	_mark.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_mark.no_depth_test = true
	_mark.visible = false
	add_child(_mark)

	_wp_mark = Label3D.new()
	_wp_mark.text = "◆"
	_wp_mark.font_size = 96
	_wp_mark.pixel_size = 0.005
	_wp_mark.modulate = Color(1.0, 0.85, 0.2, 1.0)
	_wp_mark.outline_modulate = Color(0.1, 0.08, 0.0, 1.0)
	_wp_mark.outline_size = 10
	_wp_mark.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_wp_mark.no_depth_test = true
	_wp_mark.visible = false
	add_child(_wp_mark)


func _aim_hit() -> Dictionary:
	if not is_instance_valid(player):
		return {}
	var cam := player.call("get_camera") as Camera3D
	if cam == null:
		return {}
	var from := cam.global_position
	var to := from - cam.global_transform.basis.z * AXE_REACH
	var query := PhysicsRayQueryParameters3D.create(from, to)
	query.exclude = [(player as CollisionObject3D).get_rid()]
	var result: Dictionary = get_world_3d().direct_space_state.intersect_ray(query)
	if result.is_empty():
		return {}
	var body := result.get("collider") as Node
	if body == null or not body.is_in_group("chop_target"):
		return {}
	var tree := body.get_meta("tree_root", null) as Node3D
	if tree == null or not is_instance_valid(tree):
		return {}
	return {"tree": tree}


# A red + sits on the trunk, on the side that faces the player. After each hit it jumps to a new spot.
func _spot_for(tree: Node3D) -> Vector3:
	var key: int = tree.get_instance_id()
	if not _tree_spots.has(key):
		var to_player: Vector3 = player.global_position - tree.global_position
		to_player.y = 0.0
		var local_dir: Vector3 = tree.global_transform.basis.inverse() * to_player
		var ang: float = atan2(local_dir.x, local_dir.z) + _rng.randf_range(-0.9, 0.9)
		_tree_spots[key] = Vector3(sin(ang) * 0.5, _rng.randf_range(0.9, 4.2), cos(ang) * 0.5)
	return tree.global_transform * (_tree_spots[key] as Vector3)


func _update_aim(panel_open: bool) -> void:
	_mark.visible = false
	if not _axe_equipped or panel_open or not is_instance_valid(player):
		return
	var hit := _aim_hit()
	if hit.is_empty():
		return
	var tree: Node3D = hit["tree"]
	_mark.global_position = _spot_for(tree)
	_mark.visible = true


func _on_attack_pressed() -> void:
	if not _loaded or hud.panel_open():
		return
	if not _axe_equipped:
		hud.show_toast("اول تبر را از نوار پایین صفحه بردار.")
		return
	if _attack_cd > 0.0:
		return
	_attack_cd = AXE_COOLDOWN
	if is_instance_valid(_axe):
		_axe.call("swing")
	var hit := _aim_hit()
	if hit.is_empty():
		return
	var tree: Node3D = hit["tree"]
	_tree_spots.erase(tree.get_instance_id())
	Store.add_wood(WOOD_PER_HIT)
	hud.show_toast("+%d چوب" % WOOD_PER_HIT)


func _on_slot_pressed(index: int) -> void:
	if not _loaded or hud.panel_open():
		return
	if index == 0:
		_axe_equipped = not _axe_equipped
		if is_instance_valid(_axe):
			_axe.call("set_equipped", _axe_equipped)
		hud.set_equipped_slot(0 if _axe_equipped else -1)
		if _axe_equipped:
			hud.show_toast("تبر در دست است. روی درخت نشانه برو و «ضربه» را بزن.")
		else:
			hud.show_toast("تبر کنار گذاشته شد.")
	else:
		hud.show_toast("این جای خالی است.")


# ---------- helpers ----------

func _limit_visibility(node: Node, distance: float = TREE_VISIBLE_DISTANCE) -> void:
	var mesh := node as MeshInstance3D
	if mesh != null:
		mesh.visibility_range_end = distance
		mesh.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_DISABLED
	for child in node.get_children():
		_limit_visibility(child, distance)


# Called by the BugGuard autoload when FPS stays low. 0 = full, 1 = medium, 2 = light.
func apply_quality(level: int) -> void:
	level = clampi(level, 0, 2)
	if _sun != null:
		_sun.shadow_enabled = level < 2
		_sun.directional_shadow_max_distance = QUALITY_SHADOW_DISTANCE[level]
	for tree in _tree_roots:
		if is_instance_valid(tree):
			_limit_visibility(tree, QUALITY_TREE_DISTANCE[level])


func _far_from_trees(pos: Vector2, min_dist: float) -> bool:
	for other in _tree_positions:
		if other.distance_to(pos) < min_dist:
			return false
	return true


func _spawn_pumpkin() -> void:
	var origin := Vector2(player.global_position.x, player.global_position.z)
	for attempt in range(25):
		var angle := _rng.randf() * TAU
		var dist := _rng.randf_range(12.0, 55.0)
		var pos := origin + Vector2(cos(angle), sin(angle)) * dist
		if TerrainScript.height_at(pos.x, pos.y) < 0.4:
			continue
		if not _far_from_trees(pos, 2.2):
			continue
		var clear := true
		for pumpkin in _pumpkins:
			if is_instance_valid(pumpkin) and Vector2(pumpkin.position.x, pumpkin.position.z).distance_to(pos) < 6.0:
				clear = false
				break
		if not clear:
			continue
		var pumpkin := PumpkinScript.new()
		pumpkin.position = Vector3(pos.x, TerrainScript.height_at(pos.x, pos.y), pos.y)
		pumpkin.rotation.y = _rng.randf() * TAU
		add_child(pumpkin)
		_pumpkins.append(pumpkin)
		return
